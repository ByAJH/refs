#include "__cf_TBCC_Dyn.h"
#ifndef RTW_HEADER_TBCC_Dyn_acc_h_
#define RTW_HEADER_TBCC_Dyn_acc_h_
#include <stddef.h>
#include <float.h>
#include <string.h>
#ifndef TBCC_Dyn_acc_COMMON_INCLUDES_
#define TBCC_Dyn_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "stdio.h"
#include "types_TMATS.h"
#endif
#include "TBCC_Dyn_acc_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rt_look.h"
#include "rt_look1d.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { int32_T IfActionSubsystem3_sysIdxToRun ; int8_T
IfActionSubsystem3_SubsysRanBC ; char_T pad_IfActionSubsystem3_SubsysRanBC [
3 ] ; } DW_IfActionSubsystem3_TBCC_Dyn_T ; typedef struct { int32_T
IfActionSubsystem1_sysIdxToRun ; int8_T IfActionSubsystem1_SubsysRanBC ;
char_T pad_IfActionSubsystem1_SubsysRanBC [ 3 ] ; }
DW_IfActionSubsystem1_TBCC_Dyn_T ; typedef struct { real_T
StateSpace_CSTATE_k ; } X_IfActionSubsystem1_TBCC_Dyn_T ; typedef struct {
real_T StateSpace_CSTATE_k ; } XDot_IfActionSubsystem1_TBCC_Dyn_T ; typedef
struct { boolean_T StateSpace_CSTATE_k ; } XDis_IfActionSubsystem1_TBCC_Dyn_T
; typedef struct { real_T B_29_0_0 ; real_T B_29_1_0 ; real_T B_29_5_0 ;
real_T B_29_8_0 ; real_T B_29_12_0 ; real_T B_29_14_0 ; real_T B_29_20_0 ;
real_T B_29_22_0 ; real_T B_29_24_0 ; real_T B_29_26_0 ; real_T B_29_27_0 ;
real_T B_29_29_0 ; real_T B_29_33_0 ; real_T B_29_34_0 ; real_T B_29_35_0 ;
real_T B_29_36_0 ; real_T B_29_40_0 ; real_T B_29_41_0 ; real_T B_29_47_0 ;
real_T B_29_49_0 ; real_T B_29_50_0 ; real_T B_29_52_0 ; real_T B_29_135_0 ;
real_T B_29_137_0 ; real_T B_29_139_0 ; real_T B_29_141_0 ; real_T B_29_143_0
; real_T B_29_146_0 ; real_T B_29_148_0 ; real_T B_29_151_0 ; real_T
B_29_152_0 ; real_T B_29_156_0 ; real_T B_29_157_0 ; real_T B_29_159_0 ;
real_T B_29_162_0 ; real_T B_29_166_0 ; real_T B_29_167_0 ; real_T B_29_169_0
; real_T B_29_171_0 ; real_T B_29_174_0 ; real_T B_29_175_0 ; real_T
B_29_177_0 ; real_T B_29_178_0 ; real_T B_29_182_0 ; real_T B_29_185_0 ;
real_T B_29_191_0 ; real_T B_29_192_0 [ 5 ] ; real_T B_29_193_0 [ 3 ] ;
real_T B_29_194_0 [ 5 ] ; real_T B_29_195_0 [ 3 ] ; real_T B_29_4_0 ; real_T
B_29_16_0 ; real_T B_29_37_0 ; real_T B_29_38_0 ; real_T B_29_0_0_m ; real_T
B_29_1_0_c ; real_T B_29_2_0 ; real_T B_29_3_0 ; real_T B_29_5_0_k ; real_T
B_29_6_0 ; real_T B_29_8_0_c ; real_T B_29_9_0 ; real_T B_29_10_0 ; real_T
B_29_11_0 ; real_T B_28_1_0 [ 2 ] ; real_T B_28_0_0 ; real_T B_28_1_0_b ;
real_T B_27_4_0 [ 3 ] ; real_T B_27_5_0 [ 8 ] ; real_T B_27_11_0 ; real_T
B_27_23_0 [ 12 ] ; real_T B_27_24_0 [ 27 ] ; real_T B_27_24_1 [ 5 ] ; real_T
B_27_24_2 [ 5 ] ; real_T B_27_25_0 [ 6 ] ; real_T B_27_26_0 [ 6 ] ; real_T
B_27_38_0 [ 12 ] ; real_T B_27_39_0 [ 20 ] ; real_T B_27_41_0 [ 8 ] ; real_T
B_27_42_0 [ 17 ] ; real_T B_27_48_0 ; real_T B_27_52_0 ; real_T B_27_0_0 ;
real_T B_27_1_0 ; real_T B_27_2_0 ; real_T B_27_3_0 ; real_T B_27_4_0_p ;
real_T B_27_5_0_c ; real_T B_27_6_0 ; real_T B_27_7_0 ; real_T B_27_8_0 ;
real_T B_27_12_0 ; real_T B_27_13_0 ; real_T B_27_14_0 ; real_T B_27_16_0 ;
real_T B_27_17_0 ; real_T B_27_19_0 ; real_T B_27_22_0 ; real_T B_27_23_0_f ;
real_T B_27_24_0_g ; real_T B_27_28_0 ; real_T B_27_29_0 ; real_T B_27_30_0 ;
real_T B_27_31_0 ; real_T B_27_32_0 ; real_T B_27_36_0 ; real_T B_27_37_0 ;
real_T B_27_39_0_g ; real_T B_26_0_0 ; real_T B_26_1_0 ; real_T B_25_1_0 [ 3
] ; real_T B_25_3_0 [ 3 ] ; real_T B_24_11_0 [ 3 ] ; real_T B_24_0_0 [ 3 ] ;
real_T B_24_1_0 [ 3 ] ; real_T B_24_2_0 ; real_T B_24_3_0 ; real_T B_24_4_0 ;
real_T B_21_1_0 [ 3 ] ; real_T B_21_4_0 [ 3 ] ; real_T B_21_0_0 [ 3 ] ;
real_T B_20_4_0 ; real_T B_20_0_0 [ 6 ] ; real_T B_20_1_0 ; real_T B_20_4_0_m
; real_T B_19_0_0 [ 3 ] ; real_T B_19_1_0 [ 9 ] ; real_T B_19_2_0 [ 21 ] ;
real_T B_19_3_0 ; real_T B_18_0_1 [ 3 ] ; real_T B_18_0_2 [ 9 ] ; real_T
B_18_0_3 [ 9 ] ; real_T B_18_0_4 [ 21 ] ; real_T B_18_0_5 ; real_T B_17_0_0 [
5 ] ; real_T B_16_0_0 [ 3 ] ; real_T B_15_0_0 [ 5 ] ; real_T B_13_0_0 ;
real_T B_13_8_0 ; real_T B_13_9_0 ; real_T B_11_0_0 ; real_T B_11_6_0 ;
real_T B_7_1_0 ; real_T B_0_3_0 ; real_T B_0_5_0 ; uint32_T B_21_1_0_n ;
boolean_T B_27_27_0 ; boolean_T B_27_43_0 ; boolean_T B_27_49_0 ; boolean_T
B_27_11_0_p ; boolean_T B_27_27_0_l ; boolean_T B_27_35_0 ; boolean_T
B_26_3_0 ; boolean_T B_25_0_0 ; boolean_T B_24_16_0 [ 3 ] ; boolean_T
B_20_5_0 ; boolean_T B_20_6_0 ; char_T pad_B_20_6_0 [ 7 ] ; } B_TBCC_Dyn_T ;
typedef struct { real_T UnitDelay_DSTATE ; real_T UnitDelay_DSTATE_k [ 3 ] ;
real_T UnitDelay_DSTATE_c [ 3 ] ; real_T UnitDelay_DSTATE_g ; real_T
UnitDelay2_DSTATE [ 3 ] ; real_T UnitDelay_DSTATE_kh [ 9 ] ; real_T
UnitDelay1_DSTATE [ 21 ] ; real_T UnitDelay3_DSTATE ; real_T
TmpRTBAtIfActionSubsystem3Inport1_Buffer0 ; real_T
TmpRTBAtIfActionSubsystem1Inport1_Buffer0 ; real_T
TmpRTBAtIfActionSubsystem4Inport1_Buffer0 ; real_T
TmpRTBAtDivideInport2_Buffer0 ; real_T TmpRTBAtProductInport2_Buffer0 ;
real_T TmpRTBAtSqrt2Outport1_Buffer0 ; real_T TmpRTBAtProduct6Inport2_Buffer0
; real_T TmpRTBAtProduct3Inport1_Buffer0 ; real_T
TmpRTBAtDivide2Inport2_Buffer0 ; real_T
TmpRTBAtIfActionSubsystem1Inport1_Buffer0_h ; real_T
TmpRTBAtIfActionSubsystem1Inport1_Buffer0_hu ; real_T
TmpRTBAtIfActionSubsystemInport1_Buffer0 ; real_T
TmpRTBAtIfActionSubsystem2Inport1_Buffer0 ; real_T
TmpRTBAtBiasOutport1_Buffer0 ; real_T TmpRTBAtProduct1Inport2_Buffer0 ;
real_T TmpRTBAtProduct5Inport2_Buffer0 ; real_T
TmpRTBAtProduct6Inport2_Buffer0_l ; real_T Memory_PreviousInput [ 3 ] ;
real_T NextOutput ; struct { real_T modelTStart ; } TransportDelay_RWORK ;
struct { real_T modelTStart ; } TransportDelay_RWORK_k ; struct { real_T
modelTStart ; } TransportDelay_RWORK_a ; void * Scope_PWORK [ 6 ] ; void *
Scope1_PWORK [ 4 ] ; void * Scope_PWORK_c ; void * Scope2_PWORK ; void *
Scope1_PWORK_a [ 3 ] ; void * Scope2_PWORK_b [ 3 ] ; void * Scope3_PWORK [ 3
] ; void * Scope4_PWORK ; void * Scope5_PWORK ; void * Scope6_PWORK ; void *
Scope_PWORK_p ; void * Scope1_PWORK_c ; void * Scope2_PWORK_g ; void *
Scope3_PWORK_p ; void * Scope2_PWORK_g3 [ 3 ] ; void * Scope1_PWORK_j ; void
* Scope3_PWORK_o ; void * Scope_PWORK_f ; struct { void * TUbufferPtrs [ 2 ]
; } TransportDelay_PWORK ; struct { void * TUbufferPtrs [ 2 ] ; }
TransportDelay_PWORK_k ; struct { void * TUbufferPtrs [ 2 ] ; }
TransportDelay_PWORK_h ; int32_T XYGraph_sysIdxToRun ; int32_T _sysIdxToRun ;
int32_T NRwCond_sysIdxToRun ; int32_T NewtonRaphsonSolver_sysIdxToRun ;
int32_T NRUpdate_sysIdxToRun ; int32_T Error_sysIdxToRun ; int32_T
MATLABFunction_sysIdxToRun ; int32_T JCwReset_sysIdxToRun ; int32_T
JacobianCalculator_sysIdxToRun ; int32_T Jacobian_sysIdxToRun ; int32_T
JacobianCalc_sysIdxToRun ; int32_T Scalar_To_Workspace_sysIdxToRun ; int32_T
C_To_Workspace_sysIdxToRun ; int32_T Scalar_To_Workspace_sysIdxToRun_c ;
int32_T IfActionSubsystem1_sysIdxToRun ; int32_T
IfActionSubsystem1_sysIdxToRun_n ; int32_T IfActionSubsystem2_sysIdxToRun ;
int32_T IfActionSubsystem_sysIdxToRun ; int32_T
IfActionSubsystem1_sysIdxToRun_i ; int32_T IfActionSubsystem2_sysIdxToRun_o ;
int32_T NoiseGenerator_sysIdxToRun ; uint32_T SumofElements_DWORK1 ; uint32_T
RandSeed ; int_T Integrator_IWORK ; int_T Integrator_IWORK_k ; struct { int_T
Errors [ 5 ] ; } AmbientEnvtoEngine_IWORK ; struct { int_T Errors [ 5 ] ; }
Compressor_IWORK ; struct { int_T Errors [ 5 ] ; } Turbine_IWORK ; struct {
int_T Errors [ 16 ] ; } Nozzle_IWORK ; struct { int_T Tail ; int_T Head ;
int_T Last ; int_T CircularBufSize ; int_T MaxNewBufSize ; }
TransportDelay_IWORK ; struct { int_T Tail ; int_T Head ; int_T Last ; int_T
CircularBufSize ; int_T MaxNewBufSize ; } TransportDelay_IWORK_b ; struct {
int_T Tail ; int_T Head ; int_T Last ; int_T CircularBufSize ; int_T
MaxNewBufSize ; } TransportDelay_IWORK_j ; int8_T If1_ActiveSubsystem ;
int8_T If2_ActiveSubsystem ; int8_T If2_ActiveSubsystem_i ; int8_T
If1_ActiveSubsystem_g ; int8_T If_ActiveSubsystem ; int8_T
NRwCond_SubsysRanBC ; int8_T NRUpdate_SubsysRanBC ; int8_T Error_SubsysRanBC
; int8_T JCwReset_SubsysRanBC ; int8_T Jacobian_SubsysRanBC ; int8_T
Scalar_To_Workspace_SubsysRanBC ; int8_T C_To_Workspace_SubsysRanBC ; int8_T
Scalar_To_Workspace_SubsysRanBC_n ; int8_T IfActionSubsystem1_SubsysRanBC ;
int8_T If3_ActiveSubsystem ; int8_T IfActionSubsystem1_SubsysRanBC_g ; int8_T
If3_ActiveSubsystem_l ; int8_T IfActionSubsystem2_SubsysRanBC ; int8_T
IfActionSubsystem_SubsysRanBC ; int8_T IfActionSubsystem1_SubsysRanBC_p ;
int8_T IfActionSubsystem2_SubsysRanBC_a ; int8_T NoiseGenerator_SubsysRanBC ;
boolean_T Memory_PreviousInput_h [ 3 ] ; boolean_T NRwCond_MODE ; boolean_T
NRUpdate_MODE ; boolean_T JCwReset_MODE ; boolean_T Jacobian_MODE ; boolean_T
NoiseGenerator_MODE ; char_T pad_NoiseGenerator_MODE [ 6 ] ;
DW_IfActionSubsystem3_TBCC_Dyn_T IfActionSubsystem4_f ;
DW_IfActionSubsystem1_TBCC_Dyn_T IfActionSubsystem2_o ;
DW_IfActionSubsystem1_TBCC_Dyn_T IfActionSubsystem2_or ;
DW_IfActionSubsystem1_TBCC_Dyn_T IfActionSubsystem1_l ;
DW_IfActionSubsystem3_TBCC_Dyn_T IfActionSubsystem3_m ;
DW_IfActionSubsystem3_TBCC_Dyn_T IfActionSubsystem1_c ;
DW_IfActionSubsystem3_TBCC_Dyn_T IfActionSubsystem4 ;
DW_IfActionSubsystem3_TBCC_Dyn_T IfActionSubsystem3 ; } DW_TBCC_Dyn_T ;
typedef struct { real_T TransferFcn_CSTATE ; real_T Integrator_CSTATE ;
real_T Integrator_CSTATE_f ; real_T Integrator_CSTATE_i ; real_T
StateSpace_CSTATE ; X_IfActionSubsystem1_TBCC_Dyn_T IfActionSubsystem2_o ;
real_T StateSpace_CSTATE_m ; X_IfActionSubsystem1_TBCC_Dyn_T
IfActionSubsystem2_or ; X_IfActionSubsystem1_TBCC_Dyn_T IfActionSubsystem1_l
; real_T StateSpace_CSTATE_o ; real_T TransferFcn1_CSTATE ; real_T
TransferFcn2_CSTATE ; real_T noisegeneratingfilter_CSTATE ; } X_TBCC_Dyn_T ;
typedef struct { real_T TransferFcn_CSTATE ; real_T Integrator_CSTATE ;
real_T Integrator_CSTATE_f ; real_T Integrator_CSTATE_i ; real_T
StateSpace_CSTATE ; XDot_IfActionSubsystem1_TBCC_Dyn_T IfActionSubsystem2_o ;
real_T StateSpace_CSTATE_m ; XDot_IfActionSubsystem1_TBCC_Dyn_T
IfActionSubsystem2_or ; XDot_IfActionSubsystem1_TBCC_Dyn_T
IfActionSubsystem1_l ; real_T StateSpace_CSTATE_o ; real_T
TransferFcn1_CSTATE ; real_T TransferFcn2_CSTATE ; real_T
noisegeneratingfilter_CSTATE ; } XDot_TBCC_Dyn_T ; typedef struct { boolean_T
TransferFcn_CSTATE ; boolean_T Integrator_CSTATE ; boolean_T
Integrator_CSTATE_f ; boolean_T Integrator_CSTATE_i ; boolean_T
StateSpace_CSTATE ; XDis_IfActionSubsystem1_TBCC_Dyn_T IfActionSubsystem2_o ;
boolean_T StateSpace_CSTATE_m ; XDis_IfActionSubsystem1_TBCC_Dyn_T
IfActionSubsystem2_or ; XDis_IfActionSubsystem1_TBCC_Dyn_T
IfActionSubsystem1_l ; boolean_T StateSpace_CSTATE_o ; boolean_T
TransferFcn1_CSTATE ; boolean_T TransferFcn2_CSTATE ; boolean_T
noisegeneratingfilter_CSTATE ; } XDis_TBCC_Dyn_T ; typedef struct {
ZCSigState Error_Trig_ZCE [ 3 ] ; } PrevZCX_TBCC_Dyn_T ; typedef struct {
const real_T B_27_3_0 ; const real_T B_17_0_0 ; const real_T B_16_0_0 ; const
real_T B_15_0_0 ; } ConstB_TBCC_Dyn_T ;
#define TBCC_Dyn_rtC(S) ((ConstB_TBCC_Dyn_T *) _ssGetConstBlockIO(S))
typedef struct { real_T MATLABFunction_BlkNm_M_Size [ 2 ] ; real_T
MATLABFunction_BlkNm_M [ 85 ] ; } ConstP_TBCC_Dyn_T ; struct
P_IfActionSubsystem1_TBCC_Dyn_T_ { real_T P_0 ; real_T P_1 ; real_T P_2 ;
real_T P_3 ; } ; struct P_TBCC_Dyn_T_ { real_T P_0 ; real_T P_1 ; real_T P_2
; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8
; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T
P_14 ; real_T P_15 ; real_T P_16 ; real_T P_17 ; real_T P_18 ; real_T P_19 ;
real_T P_20 ; real_T P_21 ; real_T P_22 ; real_T P_23 ; real_T P_24 ; real_T
P_25 ; real_T P_26 ; real_T P_27 [ 7 ] ; real_T P_28 [ 7 ] ; real_T P_29 ;
real_T P_30 ; real_T P_31 ; real_T P_32 ; real_T P_34 [ 7 ] ; real_T P_35 [ 7
] ; real_T P_36 ; real_T P_37 ; real_T P_38 [ 3 ] ; real_T P_39 [ 9 ] ;
real_T P_40 [ 21 ] ; real_T P_41 ; real_T P_42 ; real_T P_43 [ 6 ] ; real_T
P_44 ; real_T P_45 ; real_T P_46 ; real_T P_47 [ 3 ] ; real_T P_48 [ 3 ] ;
real_T P_49 [ 3 ] ; real_T P_50 [ 3 ] ; real_T P_51 [ 3 ] ; real_T P_52 ;
real_T P_53 ; real_T P_54 ; real_T P_55 [ 3 ] ; real_T P_56 ; real_T P_57 ;
real_T P_58 [ 15 ] ; real_T P_59 [ 15 ] ; real_T P_60 [ 15 ] ; real_T P_61 [
7 ] ; real_T P_62 [ 2 ] ; real_T P_63 [ 7 ] ; real_T P_64 [ 14 ] ; real_T
P_65 ; real_T P_66 [ 2 ] ; real_T P_67 [ 2 ] ; real_T P_68 [ 3 ] ; real_T
P_69 [ 13 ] ; real_T P_70 [ 11 ] ; real_T P_71 ; real_T P_72 [ 143 ] ; real_T
P_73 [ 143 ] ; real_T P_74 [ 143 ] ; real_T P_75 ; real_T P_76 ; real_T P_77
; real_T P_78 ; real_T P_79 [ 14 ] ; real_T P_80 [ 14 ] ; real_T P_81 ;
real_T P_82 ; real_T P_83 ; real_T P_84 ; real_T P_85 ; real_T P_86 ; real_T
P_87 ; real_T P_88 ; real_T P_89 ; real_T P_90 ; real_T P_91 ; real_T P_92 ;
real_T P_93 ; real_T P_94 ; real_T P_95 ; real_T P_96 ; real_T P_97 ; real_T
P_98 ; real_T P_99 ; real_T P_100 ; real_T P_101 ; real_T P_102 ; real_T
P_103 ; real_T P_104 ; real_T P_105 [ 53 ] ; real_T P_106 ; real_T P_107 [ 2
] ; real_T P_108 [ 6 ] ; real_T P_109 [ 20 ] ; real_T P_110 [ 120 ] ; real_T
P_111 [ 120 ] ; real_T P_112 ; real_T P_113 ; real_T P_114 ; real_T P_115 ;
real_T P_116 ; real_T P_117 ; real_T P_118 ; real_T P_119 ; real_T P_120 ;
real_T P_121 ; real_T P_122 ; real_T P_123 ; real_T P_124 ; real_T P_125 ;
real_T P_126 ; real_T P_127 [ 8 ] ; real_T P_128 [ 8 ] ; real_T P_129 [ 18 ]
; real_T P_130 [ 144 ] ; real_T P_131 [ 2 ] ; real_T P_132 [ 2 ] ; real_T
P_133 [ 2 ] ; real_T P_134 [ 2 ] ; real_T P_135 [ 18 ] ; real_T P_136 [ 18 ]
; real_T P_137 ; real_T P_138 ; real_T P_139 ; real_T P_140 ; real_T P_141 ;
real_T P_142 [ 50 ] ; real_T P_143 ; real_T P_144 ; real_T P_145 ; real_T
P_146 ; real_T P_147 ; real_T P_148 ; real_T P_149 ; real_T P_150 ; real_T
P_151 ; real_T P_152 ; real_T P_153 ; real_T P_154 ; real_T P_155 ; real_T
P_156 ; real_T P_157 ; real_T P_158 ; real_T P_159 ; real_T P_160 ; real_T
P_161 ; real_T P_162 ; real_T P_163 ; real_T P_164 ; real_T P_165 ; real_T
P_166 ; real_T P_167 ; real_T P_168 ; real_T P_169 ; real_T P_170 ; real_T
P_171 ; real_T P_172 ; real_T P_173 ; real_T P_174 ; real_T P_175 ; real_T
P_176 ; real_T P_177 [ 7 ] ; real_T P_178 [ 7 ] ; real_T P_179 ; real_T P_180
; real_T P_181 ; real_T P_182 ; real_T P_183 ; real_T P_184 ; real_T P_185 ;
real_T P_186 [ 7 ] ; real_T P_187 [ 7 ] ; real_T P_188 [ 7 ] ; real_T P_189 [
7 ] ; real_T P_190 [ 7 ] ; real_T P_191 [ 7 ] ; real_T P_192 ; real_T P_193 ;
real_T P_194 ; real_T P_195 ; real_T P_196 ; real_T P_197 ; real_T P_198 ;
real_T P_199 ; real_T P_200 ; real_T P_201 ; real_T P_202 ; real_T P_203 ;
real_T P_204 ; real_T P_205 ; real_T P_206 ; real_T P_207 [ 7 ] ; real_T
P_208 [ 7 ] ; real_T P_209 ; real_T P_210 ; real_T P_211 ; real_T P_212 ;
real_T P_213 ; real_T P_214 ; real_T P_215 ; real_T P_216 ; real_T P_217 ;
real_T P_218 ; real_T P_219 ; real_T P_220 ; real_T P_221 ; real_T P_222 ;
real_T P_223 ; real_T P_224 ; real_T P_225 ; real_T P_226 ; real_T P_227 ;
real_T P_228 ; real_T P_229 ; real_T P_230 ; real_T P_231 ; real_T P_232 ;
real_T P_233 ; real_T P_234 ; real_T P_235 ; real_T P_236 ; real_T P_237 ;
real_T P_238 ; real_T P_239 ; real_T P_240 ; real_T P_241 ; real_T P_242 ;
real_T P_243 ; real_T P_244 ; real_T P_245 ; real_T P_246 ; real_T P_247 ;
real_T P_248 ; real_T P_249 ; real_T P_250 ; real_T P_251 ; real_T P_252 ;
real_T P_253 ; real_T P_254 ; real_T P_255 ; real_T P_256 ; real_T P_257 ;
real_T P_258 ; real_T P_259 ; real_T P_260 ; real_T P_261 ; real_T P_262 ;
real_T P_263 ; int32_T P_264 ; uint32_T P_265 ; boolean_T P_266 ; char_T
pad_P_266 [ 7 ] ; P_IfActionSubsystem1_TBCC_Dyn_T IfActionSubsystem2_o ;
P_IfActionSubsystem1_TBCC_Dyn_T IfActionSubsystem2_or ;
P_IfActionSubsystem1_TBCC_Dyn_T IfActionSubsystem1_l ; } ; extern
P_TBCC_Dyn_T TBCC_Dyn_rtDefaultP ; extern const ConstB_TBCC_Dyn_T
TBCC_Dyn_rtInvariant ; extern const ConstP_TBCC_Dyn_T TBCC_Dyn_rtConstP ;
extern void mdlUpdateTID2 ( SimStruct * S , int_T tid ) ; extern void
mdlOutputsTID2 ( SimStruct * S , int_T tid ) ;
#endif
