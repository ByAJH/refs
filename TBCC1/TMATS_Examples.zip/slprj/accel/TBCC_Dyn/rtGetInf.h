#include "__cf_TBCC_Dyn.h"
#ifndef RTW_HEADER_rtGetInf_h_
#define RTW_HEADER_rtGetInf_h_
#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"
extern real_T rtGetInf ( void ) ; extern real32_T rtGetInfF ( void ) ; extern
real_T rtGetMinusInf ( void ) ; extern real32_T rtGetMinusInfF ( void ) ;
#endif
