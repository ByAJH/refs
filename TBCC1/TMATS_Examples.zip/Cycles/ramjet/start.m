clc,clear
disp("F:\tmats\ramjet")
cd  F:\tmats\ramjet
%------ Performs example setup ---------
ramjet_setup_everything;
cd ..
clear TMATS;