#include "__cf_TBCC_Dyn.h"
#include <math.h>
#include "TBCC_Dyn_acc.h"
#include "TBCC_Dyn_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "simtarget/slSimTgtMdlrefSfcnBridge.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
extern void Ambient_TMATS_body ( double * y , const double * u , const
AmbientStruct * prm ) ; AmbientStruct ambientStruct ; extern void
Compressor_TMATS_body ( double * y , double * y1 , double * y2 , const double
* u , const double * Wcust , const double * FracWbld , const CompressorStruct
* prm ) ; CompressorStruct compressorStruct ; extern void Burner_TMATS_body (
double * , const double * , const BurnStruct * ) ; BurnStruct burnPrms ;
extern void Turbine_TMATS_body ( double * y , const double * u , const double
* CoolFlow , const TurbineStruct * prm ) ; TurbineStruct turbineStruct ;
extern void Nozzle_TMATS_body ( double * y , const double * u , const
NozzleStruct * prm ) ; NozzleStruct nozzleStruct ;
#ifndef __RTW_UTFREE__  
extern void * utMalloc ( size_t ) ; extern void utFree ( void * ) ;
#endif
boolean_T TBCC_Dyn_acc_rt_TDelayUpdateTailOrGrowBuf ( int_T * bufSzPtr ,
int_T * tailPtr , int_T * headPtr , int_T * lastPtr , real_T tMinusDelay ,
real_T * * tBufPtr , real_T * * uBufPtr , real_T * * xBufPtr , boolean_T
isfixedbuf , boolean_T istransportdelay , int_T * maxNewBufSzPtr ) { int_T
testIdx ; int_T tail = * tailPtr ; int_T bufSz = * bufSzPtr ; real_T * tBuf =
* tBufPtr ; real_T * xBuf = ( NULL ) ; int_T numBuffer = 2 ; if (
istransportdelay ) { numBuffer = 3 ; xBuf = * xBufPtr ; } testIdx = ( tail <
( bufSz - 1 ) ) ? ( tail + 1 ) : 0 ; if ( ( tMinusDelay <= tBuf [ testIdx ] )
&& ! isfixedbuf ) { int_T j ; real_T * tempT ; real_T * tempU ; real_T *
tempX = ( NULL ) ; real_T * uBuf = * uBufPtr ; int_T newBufSz = bufSz + 1024
; if ( newBufSz > * maxNewBufSzPtr ) { * maxNewBufSzPtr = newBufSz ; } tempU
= ( real_T * ) utMalloc ( numBuffer * newBufSz * sizeof ( real_T ) ) ; if (
tempU == ( NULL ) ) { return ( false ) ; } tempT = tempU + newBufSz ; if (
istransportdelay ) tempX = tempT + newBufSz ; for ( j = tail ; j < bufSz ; j
++ ) { tempT [ j - tail ] = tBuf [ j ] ; tempU [ j - tail ] = uBuf [ j ] ; if
( istransportdelay ) tempX [ j - tail ] = xBuf [ j ] ; } for ( j = 0 ; j <
tail ; j ++ ) { tempT [ j + bufSz - tail ] = tBuf [ j ] ; tempU [ j + bufSz -
tail ] = uBuf [ j ] ; if ( istransportdelay ) tempX [ j + bufSz - tail ] =
xBuf [ j ] ; } if ( * lastPtr > tail ) { * lastPtr -= tail ; } else { *
lastPtr += ( bufSz - tail ) ; } * tailPtr = 0 ; * headPtr = bufSz ; utFree (
uBuf ) ; * bufSzPtr = newBufSz ; * tBufPtr = tempT ; * uBufPtr = tempU ; if (
istransportdelay ) * xBufPtr = tempX ; } else { * tailPtr = testIdx ; }
return ( true ) ; } real_T TBCC_Dyn_acc_rt_TDelayInterpolate ( real_T
tMinusDelay , real_T tStart , real_T * tBuf , real_T * uBuf , int_T bufSz ,
int_T * lastIdx , int_T oldestIdx , int_T newIdx , real_T initOutput ,
boolean_T discrete , boolean_T minorStepAndTAtLastMajorOutput ) { int_T i ;
real_T yout , t1 , t2 , u1 , u2 ; if ( ( newIdx == 0 ) && ( oldestIdx == 0 )
&& ( tMinusDelay > tStart ) ) return initOutput ; if ( tMinusDelay <= tStart
) return initOutput ; if ( ( tMinusDelay <= tBuf [ oldestIdx ] ) ) { if (
discrete ) { return ( uBuf [ oldestIdx ] ) ; } else { int_T tempIdx =
oldestIdx + 1 ; if ( oldestIdx == bufSz - 1 ) tempIdx = 0 ; t1 = tBuf [
oldestIdx ] ; t2 = tBuf [ tempIdx ] ; u1 = uBuf [ oldestIdx ] ; u2 = uBuf [
tempIdx ] ; if ( t2 == t1 ) { if ( tMinusDelay >= t2 ) { yout = u2 ; } else {
yout = u1 ; } } else { real_T f1 = ( t2 - tMinusDelay ) / ( t2 - t1 ) ;
real_T f2 = 1.0 - f1 ; yout = f1 * u1 + f2 * u2 ; } return yout ; } } if (
minorStepAndTAtLastMajorOutput ) { if ( newIdx != 0 ) { if ( * lastIdx ==
newIdx ) { ( * lastIdx ) -- ; } newIdx -- ; } else { if ( * lastIdx == newIdx
) { * lastIdx = bufSz - 1 ; } newIdx = bufSz - 1 ; } } i = * lastIdx ; if (
tBuf [ i ] < tMinusDelay ) { while ( tBuf [ i ] < tMinusDelay ) { if ( i ==
newIdx ) break ; i = ( i < ( bufSz - 1 ) ) ? ( i + 1 ) : 0 ; } } else { while
( tBuf [ i ] >= tMinusDelay ) { i = ( i > 0 ) ? i - 1 : ( bufSz - 1 ) ; } i =
( i < ( bufSz - 1 ) ) ? ( i + 1 ) : 0 ; } * lastIdx = i ; if ( discrete ) {
double tempEps = ( DBL_EPSILON ) * 128.0 ; double localEps = tempEps *
muDoubleScalarAbs ( tBuf [ i ] ) ; if ( tempEps > localEps ) { localEps =
tempEps ; } localEps = localEps / 2.0 ; if ( tMinusDelay >= ( tBuf [ i ] -
localEps ) ) { yout = uBuf [ i ] ; } else { if ( i == 0 ) { yout = uBuf [
bufSz - 1 ] ; } else { yout = uBuf [ i - 1 ] ; } } } else { if ( i == 0 ) {
t1 = tBuf [ bufSz - 1 ] ; u1 = uBuf [ bufSz - 1 ] ; } else { t1 = tBuf [ i -
1 ] ; u1 = uBuf [ i - 1 ] ; } t2 = tBuf [ i ] ; u2 = uBuf [ i ] ; if ( t2 ==
t1 ) { if ( tMinusDelay >= t2 ) { yout = u2 ; } else { yout = u1 ; } } else {
real_T f1 = ( t2 - tMinusDelay ) / ( t2 - t1 ) ; real_T f2 = 1.0 - f1 ; yout
= f1 * u1 + f2 * u2 ; } } return ( yout ) ; } real_T look1_binlcapw ( real_T
u0 , const real_T bp0 [ ] , const real_T table [ ] , uint32_T maxIndex ) {
real_T y ; real_T frac ; uint32_T iRght ; uint32_T iLeft ; uint32_T bpIdx ;
if ( u0 <= bp0 [ 0U ] ) { iLeft = 0U ; frac = 0.0 ; } else if ( u0 < bp0 [
maxIndex ] ) { bpIdx = maxIndex >> 1U ; iLeft = 0U ; iRght = maxIndex ; while
( iRght - iLeft > 1U ) { if ( u0 < bp0 [ bpIdx ] ) { iRght = bpIdx ; } else {
iLeft = bpIdx ; } bpIdx = ( iRght + iLeft ) >> 1U ; } frac = ( u0 - bp0 [
iLeft ] ) / ( bp0 [ iLeft + 1U ] - bp0 [ iLeft ] ) ; } else { iLeft =
maxIndex ; frac = 0.0 ; } if ( iLeft == maxIndex ) { y = table [ iLeft ] ; }
else { y = ( table [ iLeft + 1U ] - table [ iLeft ] ) * frac + table [ iLeft
] ; } return y ; } void rt_ssGetBlockPath ( SimStruct * S , int_T sysIdx ,
int_T blkIdx , char_T * * path ) { _ssGetBlockPath ( S , sysIdx , blkIdx ,
path ) ; } void rt_ssSet_slErrMsg ( SimStruct * S , void * diag ) { if ( !
_ssIsErrorStatusAslErrMsg ( S ) ) { _ssSet_slErrMsg ( S , diag ) ; } else {
_ssDiscardDiagnostic ( S , diag ) ; } } void rt_ssReportDiagnosticAsWarning (
SimStruct * S , void * diag ) { _ssReportDiagnosticAsWarning ( S , diag ) ; }
void TBCC_Dyn_IfActionSubsystem3 ( SimStruct * S , real_T rtu_In1 , real_T *
rty_Out1 ) { * rty_Out1 = rtu_In1 ; } void TBCC_Dyn_IfActionSubsystem3_Term (
SimStruct * const S ) { } void TBCC_Dyn_IfActionSubsystem1_Init ( SimStruct *
S , P_IfActionSubsystem1_TBCC_Dyn_T * localP ,
X_IfActionSubsystem1_TBCC_Dyn_T * localX ) { localX -> StateSpace_CSTATE_k =
localP -> P_3 ; } void TBCC_Dyn_IfActionSubsystem1 ( SimStruct * S , real_T *
rty_Out1 , P_IfActionSubsystem1_TBCC_Dyn_T * localP ,
X_IfActionSubsystem1_TBCC_Dyn_T * localX ) { * rty_Out1 = 0.0 ; * rty_Out1 +=
localP -> P_2 * localX -> StateSpace_CSTATE_k ; } void
TBCC_Dyn_IfActionSubsystem1_Deriv ( SimStruct * S , real_T rtu_In1 ,
P_IfActionSubsystem1_TBCC_Dyn_T * localP , X_IfActionSubsystem1_TBCC_Dyn_T *
localX , XDot_IfActionSubsystem1_TBCC_Dyn_T * localXdot ) { localXdot ->
StateSpace_CSTATE_k = 0.0 ; localXdot -> StateSpace_CSTATE_k += localP -> P_0
* localX -> StateSpace_CSTATE_k ; localXdot -> StateSpace_CSTATE_k += localP
-> P_1 * rtu_In1 ; } void TBCC_Dyn_IfActionSubsystem1_Term ( SimStruct *
const S ) { } real_T rt_urand_Upu32_Yd_f_pw_snf ( uint32_T * u ) { uint32_T
lo ; uint32_T hi ; lo = * u % 127773U * 16807U ; hi = * u / 127773U * 2836U ;
if ( lo < hi ) { * u = 2147483647U - ( hi - lo ) ; } else { * u = lo - hi ; }
return ( real_T ) * u * 4.6566128752457969E-10 ; } real_T
rt_nrand_Upu32_Yd_f_pw_snf ( uint32_T * u ) { real_T y ; real_T sr ; real_T
si ; do { sr = 2.0 * rt_urand_Upu32_Yd_f_pw_snf ( u ) - 1.0 ; si = 2.0 *
rt_urand_Upu32_Yd_f_pw_snf ( u ) - 1.0 ; si = sr * sr + si * si ; } while (
si > 1.0 ) ; y = muDoubleScalarSqrt ( - 2.0 * muDoubleScalarLog ( si ) / si )
* sr ; return y ; } static void mdlOutputs ( SimStruct * S , int_T tid ) {
real_T B_29_7_0 ; real_T B_29_53_0 ; real_T B_29_54_0 ; real_T B_29_55_0 ;
real_T B_29_56_0 ; real_T B_29_57_0 ; real_T B_29_58_0 ; real_T B_29_59_0 ;
real_T B_29_60_0 ; real_T B_29_61_0 ; real_T B_29_62_0 ; real_T B_29_63_0 ;
real_T B_29_64_0 ; real_T B_29_65_0 ; real_T B_29_66_0 ; real_T B_29_67_0 ;
real_T B_29_68_0 ; real_T B_29_69_0 ; real_T B_29_70_0 ; real_T B_29_71_0 ;
real_T B_29_72_0 ; real_T B_29_73_0 ; real_T B_29_74_0 ; real_T B_29_75_0 ;
real_T B_29_76_0 ; real_T B_29_77_0 ; real_T B_29_78_0 ; real_T B_29_79_0 ;
real_T B_29_80_0 ; real_T B_29_81_0 ; real_T B_29_82_0 ; real_T B_29_83_0 ;
real_T B_29_84_0 ; real_T B_29_85_0 ; real_T B_29_86_0 ; real_T B_29_87_0 ;
real_T B_29_88_0 ; real_T B_29_89_0 ; real_T B_29_90_0 ; real_T B_29_91_0 ;
real_T B_29_92_0 ; real_T B_29_93_0 ; real_T B_29_94_0 ; real_T B_29_95_0 ;
real_T B_29_96_0 ; real_T B_29_97_0 ; real_T B_29_98_0 ; real_T B_29_99_0 ;
real_T B_29_100_0 ; real_T B_29_101_0 ; real_T B_29_102_0 ; real_T B_29_103_0
; real_T B_29_104_0 ; real_T B_29_105_0 [ 53 ] ; real_T B_29_106_0 ; real_T
B_29_107_0 ; real_T B_29_108_0 ; real_T B_29_109_0 ; real_T B_29_110_0 ;
real_T B_29_111_0 ; real_T B_29_112_0 ; real_T B_29_113_0 ; real_T B_29_114_0
; real_T B_29_115_0 ; real_T B_29_116_0 ; real_T B_29_117_0 ; real_T
B_29_118_0 ; real_T B_29_119_0 ; real_T B_29_120_0 ; real_T B_29_121_0 ;
real_T B_29_122_0 ; real_T B_29_123_0 ; real_T B_29_124_0 ; real_T B_29_125_0
[ 50 ] ; real_T B_29_126_0 ; real_T B_29_127_0 ; real_T B_29_128_0 ; real_T
B_29_129_0 ; real_T B_29_130_0 ; real_T B_29_132_0 [ 3 ] ; real_T B_29_133_0
; real_T B_29_165_0 ; real_T B_27_30_0 ; int32_T B_29_131_0 ; real_T
rtb_B_29_44_0 ; real_T rtb_B_29_138_0 ; real_T rtb_B_29_149_0 ; int8_T
rtAction ; int8_T rtPrevAction ; real_T rtb_B_29_13_0 ; real_T rtb_B_29_17_0
; int32_T Iter ; int32_T rtb_B_27_10_0 ; real_T rtb_B_27_6_0 ; real_T
rtb_B_27_9_0 ; real_T rtb_B_27_40_0 ; real_T rtb_B_27_0_0 ; real_T
rtb_B_27_1_0 ; real_T rtb_B_27_2_0 ; real_T rtb_B_27_3_0 ; real_T
rtb_B_27_29_0 [ 53 ] ; real_T rtb_B_27_51_0 [ 50 ] ; boolean_T rtb_B_26_5_0 ;
int32_T i ; real_T tmp [ 3 ] ; real_T B_27_13_0_idx_0 ; real_T
B_27_13_0_idx_1 ; real_T B_27_13_0_idx_2 ; real_T B_27_31_0_idx_0 ; real_T
B_27_31_0_idx_1 ; real_T B_24_3_0_idx_0 ; real_T B_24_3_0_idx_1 ; real_T
B_24_3_0_idx_2 ; boolean_T B_24_17_0_idx_0 ; boolean_T B_24_17_0_idx_1 ;
boolean_T B_24_17_0_idx_2 ; int32_T i_0 ; B_TBCC_Dyn_T * _rtB ; P_TBCC_Dyn_T
* _rtP ; X_TBCC_Dyn_T * _rtX ; PrevZCX_TBCC_Dyn_T * _rtZCE ; DW_TBCC_Dyn_T *
_rtDW ; _rtDW = ( ( DW_TBCC_Dyn_T * ) ssGetRootDWork ( S ) ) ; _rtZCE = ( (
PrevZCX_TBCC_Dyn_T * ) _ssGetPrevZCSigState ( S ) ) ; _rtX = ( ( X_TBCC_Dyn_T
* ) ssGetContStates ( S ) ) ; _rtP = ( ( P_TBCC_Dyn_T * ) ssGetModelRtp ( S )
) ; _rtB = ( ( B_TBCC_Dyn_T * ) _ssGetModelBlockIO ( S ) ) ; if (
ssIsContinuousTask ( S , 0 ) != 0 ) { _rtB -> B_29_0_0 = 0.0 ; _rtB ->
B_29_0_0 += _rtP -> P_175 * _rtX -> TransferFcn_CSTATE ; i = ssIsSampleHit (
S , 1 , 0 ) ; if ( i != 0 ) { i = ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if
( i != 0 ) { _rtB -> B_29_1_0 = _rtDW ->
TmpRTBAtIfActionSubsystem3Inport1_Buffer0 ; } } if ( ssIsMajorTimeStep ( S )
!= 0 ) { rtAction = ( int8_T ) ! ( _rtB -> B_29_0_0 > 0.0 ) ; _rtDW ->
If1_ActiveSubsystem = rtAction ; } else { rtAction = _rtDW ->
If1_ActiveSubsystem ; } switch ( rtAction ) { case 0 : _rtB -> B_29_5_0 = 0.0
; _rtB -> B_29_5_0 += _rtP -> P_12 * _rtX -> TransferFcn2_CSTATE ; if (
ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
IfActionSubsystem2_SubsysRanBC_a ) ; } break ; case 1 :
TBCC_Dyn_IfActionSubsystem3 ( S , _rtB -> B_29_1_0 , & _rtB -> B_29_5_0 ) ;
if ( ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
IfActionSubsystem3 . IfActionSubsystem3_SubsysRanBC ) ; } break ; } B_29_7_0
= rt_Lookup ( _rtP -> P_177 , 7 , ssGetT ( S ) , _rtP -> P_178 ) ; i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { i = ssIsSpecialSampleHit ( S ,
2 , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_29_8_0 = _rtDW ->
TmpRTBAtIfActionSubsystem1Inport1_Buffer0 ; } } rtPrevAction = _rtDW ->
If2_ActiveSubsystem ; if ( ssIsMajorTimeStep ( S ) != 0 ) { rtAction = (
int8_T ) ! ( _rtB -> B_29_5_0 > 0.0 ) ; _rtDW -> If2_ActiveSubsystem =
rtAction ; } else { rtAction = _rtDW -> If2_ActiveSubsystem ; } if ( (
rtPrevAction != rtAction ) && ( rtPrevAction == 0 ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; _rtDW ->
If3_ActiveSubsystem = - 1 ; } switch ( rtAction ) { case 0 : _rtB -> B_13_0_0
= 0.0 ; _rtB -> B_13_0_0 += _rtP -> P_31 * _rtX -> StateSpace_CSTATE ; i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { ssCallAccelRunBlock ( S , 13 ,
1 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 13 , 2 ,
SS_CALL_MDL_OUTPUTS ) ; } if ( ssIsMajorTimeStep ( S ) != 0 ) { rtAction = (
int8_T ) ! ( _rtB -> B_13_0_0 <= 7020.0 ) ; _rtDW -> If3_ActiveSubsystem =
rtAction ; } else { rtAction = _rtDW -> If3_ActiveSubsystem ; } switch (
rtAction ) { case 0 : _rtB -> B_11_0_0 = 0.0 ; _rtB -> B_11_0_0 += _rtP ->
P_25 * _rtX -> StateSpace_CSTATE_m ; if ( ssIsMajorTimeStep ( S ) != 0 ) {
rtAction = ( int8_T ) ! ( _rtB -> B_11_0_0 <= 1.0 ) ; _rtDW ->
If3_ActiveSubsystem_l = rtAction ; } else { rtAction = _rtDW ->
If3_ActiveSubsystem_l ; } switch ( rtAction ) { case 0 :
TBCC_Dyn_IfActionSubsystem1 ( S , & _rtB -> B_29_12_0 , & _rtP ->
IfActionSubsystem1_l , & _rtX -> IfActionSubsystem1_l ) ; if (
ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW -> IfActionSubsystem1_l .
IfActionSubsystem1_SubsysRanBC ) ; } break ; case 1 :
TBCC_Dyn_IfActionSubsystem1 ( S , & _rtB -> B_29_12_0 , & _rtP ->
IfActionSubsystem2_or , & _rtX -> IfActionSubsystem2_or ) ; if (
ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW -> IfActionSubsystem2_or
. IfActionSubsystem1_SubsysRanBC ) ; } break ; } _rtB -> B_11_6_0 = rt_Lookup
( _rtP -> P_27 , 7 , ssGetT ( S ) , _rtP -> P_28 ) ; if ( ssIsMajorTimeStep (
S ) != 0 ) { srUpdateBC ( _rtDW -> IfActionSubsystem1_SubsysRanBC_g ) ; }
break ; case 1 : TBCC_Dyn_IfActionSubsystem1 ( S , & _rtB -> B_29_12_0 , &
_rtP -> IfActionSubsystem2_o , & _rtX -> IfActionSubsystem2_o ) ; if (
ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW -> IfActionSubsystem2_o .
IfActionSubsystem1_SubsysRanBC ) ; } break ; } _rtB -> B_13_8_0 = rt_Lookup (
_rtP -> P_34 , 7 , ssGetT ( S ) , _rtP -> P_35 ) ; { real_T * * uBuffer = (
real_T * * ) & _rtDW -> TransportDelay_PWORK . TUbufferPtrs [ 0 ] ; real_T *
* tBuffer = ( real_T * * ) & _rtDW -> TransportDelay_PWORK . TUbufferPtrs [ 1
] ; real_T simTime = ssGetT ( S ) ; real_T tMinusDelay = simTime - _rtP ->
P_36 ; if ( _rtP -> P_36 == 0.0 ) _rtB -> B_13_9_0 = _rtB -> B_29_8_0 ; else
_rtB -> B_13_9_0 = TBCC_Dyn_acc_rt_TDelayInterpolate ( tMinusDelay , 0.0 , *
tBuffer , * uBuffer , _rtDW -> TransportDelay_IWORK . CircularBufSize , &
_rtDW -> TransportDelay_IWORK . Last , _rtDW -> TransportDelay_IWORK . Tail ,
_rtDW -> TransportDelay_IWORK . Head , _rtP -> P_37 , 1 , ( boolean_T ) (
ssIsMinorTimeStep ( S ) && ( ssGetTimeOfLastOutput ( S ) == ssGetT ( S ) ) )
) ; } if ( ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
IfActionSubsystem1_SubsysRanBC ) ; } break ; case 1 :
TBCC_Dyn_IfActionSubsystem3 ( S , B_29_7_0 , & _rtB -> B_29_12_0 ) ; if (
ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW -> IfActionSubsystem4_f .
IfActionSubsystem3_SubsysRanBC ) ; } break ; } rtb_B_29_13_0 = _rtX ->
Integrator_CSTATE ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtB ->
B_29_14_0 = _rtDW -> UnitDelay_DSTATE ; } B_24_3_0_idx_0 = _rtX ->
Integrator_CSTATE + _rtB -> B_29_14_0 ; if ( B_24_3_0_idx_0 > _rtP -> P_183 )
{ B_24_3_0_idx_0 = _rtP -> P_183 ; } else { if ( B_24_3_0_idx_0 < _rtP ->
P_184 ) { B_24_3_0_idx_0 = _rtP -> P_184 ; } } rtb_B_29_17_0 = _rtB ->
B_29_12_0 - B_24_3_0_idx_0 ; if ( _rtDW -> Integrator_IWORK != 0 ) { _rtX ->
Integrator_CSTATE_f = _rtB -> B_29_6_0 ; } _rtB -> B_29_20_0 = _rtP -> P_185
* rtb_B_29_17_0 + _rtX -> Integrator_CSTATE_f ; _rtB -> B_29_22_0 = rt_Lookup
( _rtP -> P_186 , 7 , ssGetT ( S ) , _rtP -> P_187 ) ; _rtB -> B_29_24_0 =
rt_Lookup ( _rtP -> P_188 , 7 , ssGetT ( S ) , _rtP -> P_189 ) ; _rtB ->
B_29_26_0 = rt_Lookup ( _rtP -> P_190 , 7 , ssGetT ( S ) , _rtP -> P_191 ) ;
if ( _rtDW -> Integrator_IWORK_k != 0 ) { _rtX -> Integrator_CSTATE_i = _rtB
-> B_29_5_0_k ; } _rtB -> B_29_27_0 = _rtX -> Integrator_CSTATE_i ; i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { Iter = 1 ; do { rtb_B_27_10_0 =
Iter ; rtb_B_27_0_0 = _rtB -> B_29_26_0 ; rtb_B_27_1_0 = _rtB -> B_29_27_0 ;
rtb_B_27_2_0 = _rtB -> B_29_26_0 ; rtb_B_27_3_0 = _rtB -> B_29_27_0 ; _rtB ->
B_27_4_0 [ 0 ] = _rtB -> B_29_22_0 ; _rtB -> B_27_4_0 [ 1 ] = _rtB ->
B_27_17_0 ; _rtB -> B_27_4_0 [ 2 ] = _rtB -> B_29_24_0 ; ambientStruct .
AFARc = _rtP -> P_65 ; ambientStruct . X_A_AltVec = ( double * ) ( _rtP ->
P_58 ) ; ambientStruct . T_A_TsVec = ( double * ) ( _rtP -> P_59 ) ;
ambientStruct . T_A_PsVec = ( double * ) ( _rtP -> P_60 ) ; ambientStruct .
X_A_FARVec = ( double * ) ( _rtP -> P_61 ) ; ambientStruct . T_A_RtArray = (
double * ) ( _rtP -> P_63 ) ; ambientStruct . Y_A_TVec = ( double * ) ( _rtP
-> P_62 ) ; ambientStruct . T_A_gammaArray = ( double * ) ( _rtP -> P_64 ) ;
ambientStruct . A = 15 ; ambientStruct . B = 7 ; ambientStruct . C = 2 ;
ambientStruct . IWork = & _rtDW -> AmbientEnvtoEngine_IWORK . Errors [ 0 ] ;
ambientStruct . BlkNm =
 "TBCC_Dyn/���緢�����ڲ��ṹģ��/InnerLoopPlant/Engine/Ambient/Ambient Env to Engine"
; Ambient_TMATS_body ( ( real_T * ) & _rtB -> B_27_5_0 [ 0 ] , ( real_T * ) &
_rtB -> B_27_4_0 [ 0 ] , & ambientStruct ) ; rtb_B_27_6_0 = _rtB -> B_29_26_0
* _rtB -> B_27_5_0 [ 6 ] / _rtB -> B_27_1_0 ; rtb_B_27_9_0 = _rtB -> B_27_5_0
[ 2 ] * _rtB -> B_27_23_0_f * look1_binlcapw ( _rtB -> B_27_5_0 [ 2 ] / _rtB
-> B_27_5_0 [ 4 ] , _rtP -> P_67 , _rtP -> P_66 , 1U ) ; _rtB -> B_27_11_0 =
_rtB -> B_27_0_0 ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { if (
_rtB -> B_27_11_0 > 0.0 ) { if ( ! _rtDW -> JCwReset_MODE ) { if (
ssGetTaskTime ( S , 1 ) != ssGetTStart ( S ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; } _rtDW -> JCwReset_MODE =
true ; } i_0 = Iter ; if ( Iter < 0 ) { i_0 = 0 ; } _rtB -> B_21_1_0 [ 0 ] =
_rtDW -> UnitDelay_DSTATE_c [ 0 ] ; _rtB -> B_21_1_0 [ 1 ] = _rtDW ->
UnitDelay_DSTATE_c [ 1 ] ; _rtB -> B_21_1_0 [ 2 ] = _rtDW ->
UnitDelay_DSTATE_c [ 2 ] ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) {
_rtB -> B_20_4_0 = muDoubleScalarMin ( ( real_T ) ( ( uint32_T ) i_0 != _rtB
-> B_21_1_0_n ) * _rtB -> B_20_4_0_m , _rtB -> B_20_1_0 + _rtDW ->
UnitDelay_DSTATE_g ) ; _rtB -> B_20_5_0 = ( _rtB -> B_20_4_0_m > _rtB ->
B_20_4_0 ) ; _rtB -> B_20_6_0 = _rtB -> B_20_5_0 ; if ( _rtB -> B_20_6_0 ) {
if ( ! _rtDW -> Jacobian_MODE ) { if ( ssGetTaskTime ( S , 1 ) != ssGetTStart
( S ) ) { ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; }
ssCallAccelRunBlock ( S , 18 , 0 , SS_CALL_RTW_GENERATED_ENABLE ) ; _rtDW ->
Jacobian_MODE = true ; } _rtB -> B_19_0_0 [ 0 ] = _rtDW -> UnitDelay2_DSTATE
[ 0 ] ; _rtB -> B_19_0_0 [ 1 ] = _rtDW -> UnitDelay2_DSTATE [ 1 ] ; _rtB ->
B_19_0_0 [ 2 ] = _rtDW -> UnitDelay2_DSTATE [ 2 ] ; memcpy ( & _rtB ->
B_19_1_0 [ 0 ] , & _rtDW -> UnitDelay_DSTATE_kh [ 0 ] , 9U * sizeof ( real_T
) ) ; memcpy ( & _rtB -> B_19_2_0 [ 0 ] , & _rtDW -> UnitDelay1_DSTATE [ 0 ]
, 21U * sizeof ( real_T ) ) ; _rtB -> B_19_3_0 = _rtDW -> UnitDelay3_DSTATE ;
ssCallAccelRunBlock ( S , 18 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtDW ->
Jacobian_SubsysRanBC = 4 ; } else { if ( _rtDW -> Jacobian_MODE ) {
ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; ssCallAccelRunBlock ( S ,
18 , 0 , SS_CALL_RTW_GENERATED_DISABLE ) ; _rtDW -> Jacobian_MODE = false ; }
} } if ( _rtB -> B_20_5_0 ) { B_27_13_0_idx_0 = _rtB -> B_18_0_1 [ 0 ] ; }
else { B_27_13_0_idx_0 = _rtB -> B_21_1_0 [ 0 ] ; } _rtB -> B_21_4_0 [ 0 ] =
B_27_13_0_idx_0 * _rtB -> B_21_0_0 [ 0 ] ; if ( _rtB -> B_20_5_0 ) {
B_27_13_0_idx_0 = _rtB -> B_18_0_1 [ 1 ] ; } else { B_27_13_0_idx_0 = _rtB ->
B_21_1_0 [ 1 ] ; } _rtB -> B_21_4_0 [ 1 ] = B_27_13_0_idx_0 * _rtB ->
B_21_0_0 [ 1 ] ; if ( _rtB -> B_20_5_0 ) { B_27_13_0_idx_0 = _rtB -> B_18_0_1
[ 2 ] ; } else { B_27_13_0_idx_0 = _rtB -> B_21_1_0 [ 2 ] ; } _rtB ->
B_21_4_0 [ 2 ] = B_27_13_0_idx_0 * _rtB -> B_21_0_0 [ 2 ] ; _rtDW ->
JCwReset_SubsysRanBC = 4 ; } else { if ( _rtDW -> JCwReset_MODE ) {
ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; if ( _rtDW ->
Jacobian_MODE ) { ssCallAccelRunBlock ( S , 18 , 0 ,
SS_CALL_RTW_GENERATED_DISABLE ) ; _rtDW -> Jacobian_MODE = false ; } _rtDW ->
JCwReset_MODE = false ; } } } B_27_13_0_idx_0 = _rtP -> P_68 [ 0 ] ;
B_27_13_0_idx_1 = _rtP -> P_68 [ 1 ] ; B_27_13_0_idx_2 = _rtP -> P_68 [ 2 ] ;
_rtB -> B_27_23_0 [ 0 ] = _rtB -> B_29_26_0 ; _rtB -> B_27_23_0 [ 1 ] = _rtB
-> B_27_5_0 [ 0 ] ; _rtB -> B_27_23_0 [ 2 ] = _rtB -> B_27_5_0 [ 1 ] ; _rtB
-> B_27_23_0 [ 3 ] = rtb_B_27_9_0 ; _rtB -> B_27_23_0 [ 4 ] = _rtB ->
B_27_5_0 [ 3 ] ; _rtB -> B_27_23_0 [ 5 ] = _rtB -> B_29_27_0 ; _rtB ->
B_27_23_0 [ 6 ] = _rtB -> B_21_4_0 [ 1 ] ; _rtB -> B_27_23_0 [ 7 ] = _rtB ->
B_27_6_0 ; _rtB -> B_27_23_0 [ 8 ] = _rtB -> B_27_2_0 ; _rtB -> B_27_23_0 [ 9
] = ( _rtP -> P_68 [ 0 ] * _rtB -> B_27_16_0 + _rtB -> B_27_12_0 ) * _rtB ->
B_27_4_0_p ; _rtB -> B_27_23_0 [ 10 ] = ( _rtP -> P_68 [ 1 ] * _rtB ->
B_27_16_0 + _rtB -> B_27_13_0 ) * _rtB -> B_27_3_0 ; _rtB -> B_27_23_0 [ 11 ]
= ( _rtP -> P_68 [ 2 ] * _rtB -> B_27_16_0 + _rtB -> B_27_14_0 ) * _rtB ->
B_27_5_0_c ; compressorStruct . NcDes = _rtP -> P_83 ; compressorStruct .
PRDes = _rtP -> P_85 ; compressorStruct . EffDes = _rtP -> P_84 ;
compressorStruct . RlineDes = _rtP -> P_86 ; compressorStruct . IDes = _rtP
-> P_81 ; compressorStruct . SMNEn = _rtP -> P_82 ; compressorStruct .
CustBldEn = _rtP -> P_87 ; compressorStruct . FBldEn = _rtP -> P_88 ;
compressorStruct . CustBldNm = _rtP -> P_89 ; compressorStruct . FracBldNm =
_rtP -> P_90 ; compressorStruct . Y_C_Map_NcVec = ( double * ) ( _rtP -> P_69
) ; compressorStruct . X_C_RlineVec = ( double * ) ( _rtP -> P_70 ) ;
compressorStruct . Z_C_AlphaVec = ( double * ) ( & _rtP -> P_71 ) ;
compressorStruct . T_C_Map_WcArray = ( double * ) ( _rtP -> P_72 ) ;
compressorStruct . T_C_Map_PRArray = ( double * ) ( _rtP -> P_73 ) ;
compressorStruct . T_C_Map_EffArray = ( double * ) ( _rtP -> P_74 ) ;
compressorStruct . FracCusBldht = ( double * ) ( & _rtP -> P_75 ) ;
compressorStruct . FracCusBldPt = ( double * ) ( & _rtP -> P_76 ) ;
compressorStruct . FracBldht = ( double * ) ( & _rtP -> P_77 ) ;
compressorStruct . FracBldPt = ( double * ) ( & _rtP -> P_78 ) ;
compressorStruct . X_C_Map_WcSurgeVec = ( double * ) ( _rtP -> P_79 ) ;
compressorStruct . T_C_Map_PRSurgeVec = ( double * ) ( _rtP -> P_80 ) ;
compressorStruct . A = 13 ; compressorStruct . B = 11 ; compressorStruct . C
= 1 ; compressorStruct . D = 14 ; compressorStruct . WcMapCol = _rtP -> P_91
; compressorStruct . PRMapCol = _rtP -> P_92 ; compressorStruct . EffMapCol =
_rtP -> P_93 ; compressorStruct . WcMapRw = _rtP -> P_94 ; compressorStruct .
PRMapRw = _rtP -> P_95 ; compressorStruct . EffMapRw = _rtP -> P_96 ;
compressorStruct . WcMapLay = _rtP -> P_97 ; compressorStruct . PRMapLay =
_rtP -> P_98 ; compressorStruct . EffMapLay = _rtP -> P_99 ; compressorStruct
. IWork = & _rtDW -> Compressor_IWORK . Errors [ 0 ] ; compressorStruct .
BlkNm =
"TBCC_Dyn/���緢�����ڲ��ṹģ��/InnerLoopPlant/Engine/Compressor/Compressor"
; Compressor_TMATS_body ( ( real_T * ) & _rtB -> B_27_24_0 [ 0 ] , ( real_T *
) & _rtB -> B_27_24_1 [ 0 ] , ( real_T * ) & _rtB -> B_27_24_2 [ 0 ] , (
real_T * ) & _rtB -> B_27_23_0 [ 0 ] , ( real_T * ) & _rtB -> B_27_7_0 , (
real_T * ) & _rtB -> B_27_8_0 , & compressorStruct ) ; _rtB -> B_27_25_0 [ 0
] = _rtB -> B_29_20_0 ; for ( i = 0 ; i < 5 ; i ++ ) { _rtB -> B_27_25_0 [ i
+ 1 ] = _rtB -> B_27_24_0 [ i ] ; } burnPrms . LHV = _rtP -> P_100 ; burnPrms
. dPnormBurner = _rtP -> P_101 ; burnPrms . Eff = _rtP -> P_102 ; burnPrms .
LHVEn = _rtP -> P_103 ; burnPrms . hFuel = _rtP -> P_104 ; Burner_TMATS_body
( ( real_T * ) & _rtB -> B_27_26_0 [ 0 ] , ( real_T * ) & _rtB -> B_27_25_0 [
0 ] , & burnPrms ) ; _rtB -> B_27_27_0 = _rtB -> B_27_11_0_p ; if ( _rtB ->
B_27_27_0 ) { _rtB -> B_15_0_0 [ 0 ] = TBCC_Dyn_rtC ( S ) -> B_15_0_0 ; _rtB
-> B_15_0_0 [ 1 ] = _rtB -> B_27_24_0 [ 8 ] ; _rtB -> B_15_0_0 [ 2 ] = _rtB
-> B_27_24_0 [ 9 ] ; _rtB -> B_15_0_0 [ 3 ] = _rtB -> B_27_24_0 [ 10 ] ; _rtB
-> B_15_0_0 [ 4 ] = _rtB -> B_27_24_0 [ 11 ] ; { FILE * fp = fopen (
"iDes_TBCC_Dyn_���緢�����ڲ��ṹģ��_InnerLoopPlant_Engine_Compressor.bin" ,
"w" ) ; int i ; for ( i = 1 ; i <= 4 ; i ++ ) { double Val = _rtB -> B_15_0_0
[ i ] ; if ( Val >= 99999 ) Val = 99999 ; else if ( Val <= - 99999 ) Val = -
99999 ; fprintf ( fp , "%f\n" , Val ) ; } fclose ( fp ) ; } _rtDW ->
Scalar_To_Workspace_SubsysRanBC_n = 4 ; } memcpy ( & rtb_B_27_29_0 [ 0 ] , &
_rtP -> P_105 [ 0 ] , 53U * sizeof ( real_T ) ) ; B_27_30_0 = _rtP -> P_106 ;
B_27_31_0_idx_0 = _rtP -> P_107 [ 0 ] ; B_27_31_0_idx_1 = _rtP -> P_107 [ 1 ]
; for ( i = 0 ; i < 5 ; i ++ ) { _rtB -> B_27_38_0 [ i ] = _rtB -> B_27_26_0
[ i ] ; } _rtB -> B_27_38_0 [ 5 ] = _rtB -> B_29_27_0 ; _rtB -> B_27_38_0 [ 6
] = _rtB -> B_21_4_0 [ 2 ] ; _rtB -> B_27_38_0 [ 7 ] = _rtB -> B_27_29_0 ;
_rtB -> B_27_38_0 [ 8 ] = ( _rtP -> P_107 [ 0 ] * _rtB -> B_27_39_0_g + _rtB
-> B_27_36_0 ) * _rtB -> B_27_31_0 ; _rtB -> B_27_38_0 [ 9 ] = _rtB ->
B_27_30_0 ; _rtB -> B_27_38_0 [ 10 ] = ( _rtP -> P_107 [ 1 ] * _rtB ->
B_27_39_0_g + _rtB -> B_27_37_0 ) * _rtB -> B_27_32_0 ; _rtB -> B_27_38_0 [
11 ] = TBCC_Dyn_rtC ( S ) -> B_27_3_0 ; turbineStruct . NcDes = _rtP -> P_116
; turbineStruct . PRmapDes = _rtP -> P_118 ; turbineStruct . EffDes = _rtP ->
P_117 ; turbineStruct . NDes = _rtP -> P_119 ; turbineStruct . IDes = _rtP ->
P_115 ; turbineStruct . BldPosLeng = _rtP -> P_113 ; turbineStruct .
CoolFlwEn = _rtP -> P_114 ; turbineStruct . ConfigNPSS = _rtP -> P_124 ;
turbineStruct . Y_T_NcVec = ( double * ) ( _rtP -> P_108 ) ; turbineStruct .
X_T_PRVec = ( double * ) ( _rtP -> P_109 ) ; turbineStruct . T_T_Map_WcArray
= ( double * ) ( _rtP -> P_110 ) ; turbineStruct . T_T_Map_EffArray = (
double * ) ( _rtP -> P_111 ) ; turbineStruct . T_BldPos = ( double * ) ( &
_rtP -> P_112 ) ; turbineStruct . A = 6 ; turbineStruct . B = 20 ;
turbineStruct . WcMapCol = _rtP -> P_120 ; turbineStruct . EffMapCol = _rtP
-> P_121 ; turbineStruct . WcMapRw = _rtP -> P_122 ; turbineStruct . EffMapRw
= _rtP -> P_123 ; turbineStruct . IWork = & _rtDW -> Turbine_IWORK . Errors [
0 ] ; turbineStruct . BlkNm =
"TBCC_Dyn/���緢�����ڲ��ṹģ��/InnerLoopPlant/Engine/Turbine/Turbine" ;
Turbine_TMATS_body ( ( real_T * ) & _rtB -> B_27_39_0 [ 0 ] , ( real_T * ) &
_rtB -> B_27_38_0 [ 0 ] , ( real_T * ) & _rtB -> B_27_24_2 [ 0 ] , &
turbineStruct ) ; rtb_B_27_40_0 = _rtB -> B_27_39_0 [ 3 ] * _rtB -> B_27_22_0
; _rtB -> B_27_41_0 [ 0 ] = _rtB -> B_27_39_0 [ 0 ] ; _rtB -> B_27_41_0 [ 1 ]
= _rtB -> B_27_39_0 [ 1 ] ; _rtB -> B_27_41_0 [ 2 ] = _rtB -> B_27_39_0 [ 2 ]
; _rtB -> B_27_41_0 [ 3 ] = rtb_B_27_40_0 ; _rtB -> B_27_41_0 [ 4 ] = _rtB ->
B_27_39_0 [ 4 ] ; _rtB -> B_27_41_0 [ 5 ] = _rtB -> B_27_5_0 [ 4 ] ; _rtB ->
B_27_41_0 [ 6 ] = _rtB -> B_27_28_0 ; _rtB -> B_27_41_0 [ 7 ] = _rtB ->
B_27_24_0_g ; nozzleStruct . SwitchType = _rtP -> P_125 ; nozzleStruct .
flowLoss = _rtP -> P_126 ; nozzleStruct . IDes = _rtP -> P_137 ; nozzleStruct
. WDes = _rtP -> P_138 ; nozzleStruct . CfgEn = _rtP -> P_139 ; nozzleStruct
. Y_N_FARVec = ( double * ) ( _rtP -> P_127 ) ; nozzleStruct . T_N_RtArray =
( double * ) ( _rtP -> P_128 ) ; nozzleStruct . X_N_TtVec = ( double * ) (
_rtP -> P_129 ) ; nozzleStruct . T_N_MAP_gammaArray = ( double * ) ( _rtP ->
P_130 ) ; nozzleStruct . X_N_PEQPaVec = ( double * ) ( _rtP -> P_131 ) ;
nozzleStruct . T_N_CdThArray = ( double * ) ( _rtP -> P_132 ) ; nozzleStruct
. T_N_CvArray = ( double * ) ( _rtP -> P_133 ) ; nozzleStruct . T_N_CfgArray
= ( double * ) ( _rtP -> P_134 ) ; nozzleStruct . T_N_TGArray = ( double * )
( _rtP -> P_135 ) ; nozzleStruct . X_N_TtVecTG = ( double * ) ( _rtP -> P_136
) ; nozzleStruct . A = 8 ; nozzleStruct . B = 18 ; nozzleStruct . B1 = 2 ;
nozzleStruct . C = 18 ; nozzleStruct . IWork = & _rtDW -> Nozzle_IWORK .
Errors [ 0 ] ; nozzleStruct . BlkNm =
"TBCC_Dyn/���緢�����ڲ��ṹģ��/InnerLoopPlant/Engine/Nozzle/Nozzle" ;
Nozzle_TMATS_body ( ( real_T * ) & _rtB -> B_27_42_0 [ 0 ] , ( real_T * ) &
_rtB -> B_27_41_0 [ 0 ] , & nozzleStruct ) ; _rtB -> B_27_43_0 = _rtB ->
B_27_27_0_l ; if ( _rtB -> B_27_43_0 ) { _rtB -> B_16_0_0 [ 0 ] =
TBCC_Dyn_rtC ( S ) -> B_16_0_0 ; _rtB -> B_16_0_0 [ 1 ] = _rtB -> B_27_42_0 [
3 ] ; _rtB -> B_16_0_0 [ 2 ] = _rtB -> B_27_42_0 [ 4 ] ; { FILE * fp = fopen
( "iDes_TBCC_Dyn_���緢�����ڲ��ṹģ��_InnerLoopPlant_Engine_Nozzle.bin" ,
"w" ) ; int i ; for ( i = 1 ; i <= 2 ; i ++ ) { double Val = _rtB -> B_16_0_0
[ i ] ; if ( Val >= 99999 ) Val = 99999 ; else if ( Val <= - 99999 ) Val = -
99999 ; fprintf ( fp , "%f\n" , Val ) ; } fclose ( fp ) ; } _rtDW ->
C_To_Workspace_SubsysRanBC = 4 ; } _rtB -> B_27_48_0 = ( _rtB -> B_27_19_0 /
_rtB -> B_29_27_0 * _rtP -> P_140 + ( _rtB -> B_27_24_0 [ 5 ] + _rtB ->
B_27_39_0 [ 5 ] ) ) * _rtP -> P_141 ; _rtB -> B_27_49_0 = _rtB -> B_27_35_0 ;
if ( _rtB -> B_27_49_0 ) { _rtB -> B_17_0_0 [ 0 ] = TBCC_Dyn_rtC ( S ) ->
B_17_0_0 ; _rtB -> B_17_0_0 [ 1 ] = _rtB -> B_27_39_0 [ 7 ] ; _rtB ->
B_17_0_0 [ 2 ] = _rtB -> B_27_39_0 [ 8 ] ; _rtB -> B_17_0_0 [ 3 ] = _rtB ->
B_27_39_0 [ 9 ] ; _rtB -> B_17_0_0 [ 4 ] = _rtB -> B_27_39_0 [ 10 ] ; { FILE
* fp = fopen (
"iDes_TBCC_Dyn_���緢�����ڲ��ṹģ��_InnerLoopPlant_Engine_Turbine.bin" ,
"w" ) ; int i ; for ( i = 1 ; i <= 4 ; i ++ ) { double Val = _rtB -> B_17_0_0
[ i ] ; if ( Val >= 99999 ) Val = 99999 ; else if ( Val <= - 99999 ) Val = -
99999 ; fprintf ( fp , "%f\n" , Val ) ; } fclose ( fp ) ; } _rtDW ->
Scalar_To_Workspace_SubsysRanBC = 4 ; } memcpy ( & rtb_B_27_51_0 [ 0 ] , &
_rtP -> P_142 [ 0 ] , 50U * sizeof ( real_T ) ) ; _rtB -> B_27_52_0 = _rtB ->
B_27_0_0 ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { if ( _rtB ->
B_27_52_0 > 0.0 ) { if ( ! _rtDW -> NRwCond_MODE ) { if ( ssGetTaskTime ( S ,
1 ) != ssGetTStart ( S ) ) { ssSetBlockStateForSolverChangedAtMajorStep ( S )
; } _rtDW -> NRwCond_MODE = true ; } _rtB -> B_26_3_0 = ( ( uint8_T ) ( ( (
uint32_T ) ( muDoubleScalarAbs ( _rtB -> B_27_42_0 [ 2 ] ) > _rtB -> B_26_0_0
) + ( muDoubleScalarAbs ( _rtB -> B_27_39_0 [ 6 ] ) > _rtB -> B_26_0_0 ) ) +
( muDoubleScalarAbs ( _rtB -> B_27_24_0 [ 6 ] ) > _rtB -> B_26_0_0 ) ) > _rtB
-> B_26_1_0 ) ; rtb_B_26_5_0 = ( ( ! _rtB -> B_20_5_0 ) && _rtB -> B_26_3_0 )
; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_25_0_0 =
rtb_B_26_5_0 ; _rtB -> B_25_1_0 [ 0 ] = _rtDW -> UnitDelay_DSTATE_k [ 0 ] ;
_rtB -> B_25_1_0 [ 1 ] = _rtDW -> UnitDelay_DSTATE_k [ 1 ] ; _rtB -> B_25_1_0
[ 2 ] = _rtDW -> UnitDelay_DSTATE_k [ 2 ] ; i = ssIsSampleHit ( S , 1 , 0 ) ;
if ( i != 0 ) { if ( _rtB -> B_25_0_0 ) { if ( ! _rtDW -> NRUpdate_MODE ) {
if ( ssGetTaskTime ( S , 1 ) != ssGetTStart ( S ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; } ssCallAccelRunBlock ( S
, 22 , 0 , SS_CALL_RTW_GENERATED_ENABLE ) ; _rtDW -> NRUpdate_MODE = true ; }
B_24_3_0_idx_0 = muDoubleScalarAbs ( _rtB -> B_24_4_0 * _rtB -> B_24_2_0 * (
_rtDW -> Memory_PreviousInput [ 0 ] + _rtB -> B_25_1_0 [ 0 ] ) ) ;
B_24_3_0_idx_1 = muDoubleScalarAbs ( _rtB -> B_24_4_0 * _rtB -> B_24_2_0 * (
_rtDW -> Memory_PreviousInput [ 1 ] + _rtB -> B_25_1_0 [ 1 ] ) ) ;
B_24_3_0_idx_2 = muDoubleScalarAbs ( _rtB -> B_24_4_0 * _rtB -> B_24_2_0 * (
_rtDW -> Memory_PreviousInput [ 2 ] + _rtB -> B_25_1_0 [ 2 ] ) ) ; for ( i_0
= 0 ; i_0 < 3 ; i_0 ++ ) { tmp [ i_0 ] = _rtB -> B_18_0_2 [ i_0 + 6 ] * _rtB
-> B_27_24_0 [ 6 ] + ( _rtB -> B_18_0_2 [ i_0 + 3 ] * _rtB -> B_27_39_0 [ 6 ]
+ _rtB -> B_18_0_2 [ i_0 ] * _rtB -> B_27_42_0 [ 2 ] ) ; } _rtB -> B_24_11_0
[ 0 ] = muDoubleScalarMin ( _rtB -> B_24_1_0 [ 0 ] , muDoubleScalarMax ( _rtB
-> B_25_1_0 [ 0 ] - muDoubleScalarMax ( _rtB -> B_24_3_0 * B_24_3_0_idx_0 ,
muDoubleScalarMin ( B_24_3_0_idx_0 , tmp [ 0 ] ) ) , _rtB -> B_24_0_0 [ 0 ] )
) ; _rtB -> B_24_16_0 [ 0 ] = ( ( _rtB -> B_24_1_0 [ 0 ] == _rtB -> B_24_11_0
[ 0 ] ) || ( _rtB -> B_24_11_0 [ 0 ] == _rtB -> B_24_0_0 [ 0 ] ) || _rtDW ->
Memory_PreviousInput_h [ 0 ] ) ; B_24_17_0_idx_0 = _rtB -> B_24_16_0 [ 0 ] ;
_rtB -> B_24_11_0 [ 1 ] = muDoubleScalarMin ( _rtB -> B_24_1_0 [ 1 ] ,
muDoubleScalarMax ( _rtB -> B_25_1_0 [ 1 ] - muDoubleScalarMax ( _rtB ->
B_24_3_0 * B_24_3_0_idx_1 , muDoubleScalarMin ( B_24_3_0_idx_1 , tmp [ 1 ] )
) , _rtB -> B_24_0_0 [ 1 ] ) ) ; _rtB -> B_24_16_0 [ 1 ] = ( ( _rtB ->
B_24_1_0 [ 1 ] == _rtB -> B_24_11_0 [ 1 ] ) || ( _rtB -> B_24_11_0 [ 1 ] ==
_rtB -> B_24_0_0 [ 1 ] ) || _rtDW -> Memory_PreviousInput_h [ 1 ] ) ;
B_24_17_0_idx_1 = _rtB -> B_24_16_0 [ 1 ] ; _rtB -> B_24_11_0 [ 2 ] =
muDoubleScalarMin ( _rtB -> B_24_1_0 [ 2 ] , muDoubleScalarMax ( _rtB ->
B_25_1_0 [ 2 ] - muDoubleScalarMax ( _rtB -> B_24_3_0 * B_24_3_0_idx_2 ,
muDoubleScalarMin ( B_24_3_0_idx_2 , tmp [ 2 ] ) ) , _rtB -> B_24_0_0 [ 2 ] )
) ; _rtB -> B_24_16_0 [ 2 ] = ( ( _rtB -> B_24_1_0 [ 2 ] == _rtB -> B_24_11_0
[ 2 ] ) || ( _rtB -> B_24_11_0 [ 2 ] == _rtB -> B_24_0_0 [ 2 ] ) || _rtDW ->
Memory_PreviousInput_h [ 2 ] ) ; B_24_17_0_idx_2 = _rtB -> B_24_16_0 [ 2 ] ;
if ( ( _rtB -> B_24_16_0 [ 0 ] && ( _rtZCE -> Error_Trig_ZCE [ 0 ] !=
POS_ZCSIG ) ) || ( _rtB -> B_24_16_0 [ 1 ] && ( _rtZCE -> Error_Trig_ZCE [ 1
] != POS_ZCSIG ) ) || ( _rtB -> B_24_16_0 [ 2 ] && ( _rtZCE -> Error_Trig_ZCE
[ 2 ] != POS_ZCSIG ) ) ) { ssCallAccelRunBlock ( S , 22 , 0 ,
SS_CALL_MDL_OUTPUTS ) ; _rtDW -> Error_SubsysRanBC = 4 ; } _rtZCE ->
Error_Trig_ZCE [ 0 ] = B_24_17_0_idx_0 ; _rtZCE -> Error_Trig_ZCE [ 1 ] =
B_24_17_0_idx_1 ; _rtZCE -> Error_Trig_ZCE [ 2 ] = B_24_17_0_idx_2 ; _rtDW ->
NRUpdate_SubsysRanBC = 4 ; } else { if ( _rtDW -> NRUpdate_MODE ) {
ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; ssCallAccelRunBlock ( S ,
22 , 0 , SS_CALL_RTW_GENERATED_DISABLE ) ; _rtDW -> NRUpdate_MODE = false ; }
} } if ( rtb_B_26_5_0 ) { _rtB -> B_25_3_0 [ 0 ] = _rtB -> B_24_11_0 [ 0 ] ;
_rtB -> B_25_3_0 [ 1 ] = _rtB -> B_24_11_0 [ 1 ] ; _rtB -> B_25_3_0 [ 2 ] =
_rtB -> B_24_11_0 [ 2 ] ; } else { _rtB -> B_25_3_0 [ 0 ] = _rtB -> B_25_1_0
[ 0 ] ; _rtB -> B_25_3_0 [ 1 ] = _rtB -> B_25_1_0 [ 1 ] ; _rtB -> B_25_3_0 [
2 ] = _rtB -> B_25_1_0 [ 2 ] ; } } _rtDW -> NRwCond_SubsysRanBC = 4 ; } else
{ if ( _rtDW -> NRwCond_MODE ) { ssSetBlockStateForSolverChangedAtMajorStep (
S ) ; if ( _rtDW -> NRUpdate_MODE ) { ssCallAccelRunBlock ( S , 22 , 0 ,
SS_CALL_RTW_GENERATED_DISABLE ) ; _rtDW -> NRUpdate_MODE = false ; } _rtDW ->
NRwCond_MODE = false ; } } } i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 )
{ if ( _rtDW -> JCwReset_MODE ) { _rtDW -> UnitDelay_DSTATE_c [ 0 ] = _rtB ->
B_25_3_0 [ 0 ] ; _rtDW -> UnitDelay_DSTATE_c [ 1 ] = _rtB -> B_25_3_0 [ 1 ] ;
_rtDW -> UnitDelay_DSTATE_c [ 2 ] = _rtB -> B_25_3_0 [ 2 ] ; i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtDW -> UnitDelay_DSTATE_g =
_rtB -> B_20_4_0 ; if ( _rtDW -> Jacobian_MODE ) { _rtDW -> UnitDelay2_DSTATE
[ 0 ] = _rtB -> B_27_42_0 [ 2 ] ; _rtDW -> UnitDelay2_DSTATE [ 1 ] = _rtB ->
B_27_39_0 [ 6 ] ; _rtDW -> UnitDelay2_DSTATE [ 2 ] = _rtB -> B_27_24_0 [ 6 ]
; memcpy ( & _rtDW -> UnitDelay_DSTATE_kh [ 0 ] , & _rtB -> B_18_0_3 [ 0 ] ,
9U * sizeof ( real_T ) ) ; memcpy ( & _rtDW -> UnitDelay1_DSTATE [ 0 ] , &
_rtB -> B_18_0_4 [ 0 ] , 21U * sizeof ( real_T ) ) ; _rtDW ->
UnitDelay3_DSTATE = _rtB -> B_18_0_5 ; } } } if ( _rtDW -> NRwCond_MODE ) { i
= ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtDW -> UnitDelay_DSTATE_k [
0 ] = _rtB -> B_25_3_0 [ 0 ] ; _rtDW -> UnitDelay_DSTATE_k [ 1 ] = _rtB ->
B_25_3_0 [ 1 ] ; _rtDW -> UnitDelay_DSTATE_k [ 2 ] = _rtB -> B_25_3_0 [ 2 ] ;
i = ssIsSampleHit ( S , 1 , 0 ) ; if ( ( i != 0 ) && _rtDW -> NRUpdate_MODE )
{ _rtDW -> Memory_PreviousInput [ 0 ] = _rtB -> B_25_1_0 [ 0 ] ; _rtDW ->
Memory_PreviousInput_h [ 0 ] = _rtB -> B_24_16_0 [ 0 ] ; _rtDW ->
Memory_PreviousInput [ 1 ] = _rtB -> B_25_1_0 [ 1 ] ; _rtDW ->
Memory_PreviousInput_h [ 1 ] = _rtB -> B_24_16_0 [ 1 ] ; _rtDW ->
Memory_PreviousInput [ 2 ] = _rtB -> B_25_1_0 [ 2 ] ; _rtDW ->
Memory_PreviousInput_h [ 2 ] = _rtB -> B_24_16_0 [ 2 ] ; } } } } Iter ++ ; }
while ( ( _rtB -> B_27_0_0 != 0.0 ) && _rtB -> B_26_3_0 && ( Iter <= 200 ) )
; i = ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if ( i != 0 ) { _rtB ->
B_29_29_0 = _rtDW -> TmpRTBAtIfActionSubsystem4Inport1_Buffer0 ; } } if (
ssIsMajorTimeStep ( S ) != 0 ) { rtAction = ( int8_T ) ! ( _rtB -> B_29_0_0 >
0.0 ) ; _rtDW -> If2_ActiveSubsystem_i = rtAction ; } else { rtAction = _rtDW
-> If2_ActiveSubsystem_i ; } switch ( rtAction ) { case 0 : _rtB -> B_29_33_0
= 0.0 ; _rtB -> B_29_33_0 += _rtP -> P_14 * _rtX -> TransferFcn1_CSTATE ; if
( ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
IfActionSubsystem1_SubsysRanBC_p ) ; } break ; case 1 :
TBCC_Dyn_IfActionSubsystem3 ( S , _rtB -> B_29_29_0 , & _rtB -> B_29_33_0 ) ;
if ( ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
IfActionSubsystem4 . IfActionSubsystem3_SubsysRanBC ) ; } break ; } _rtB ->
B_29_34_0 = _rtB -> B_29_33_0 * _rtB -> B_29_0_0 ; _rtB -> B_29_35_0 = _rtB
-> B_27_42_0 [ 1 ] + _rtB -> B_29_34_0 ; _rtB -> B_29_36_0 = _rtB ->
B_29_20_0 + _rtB -> B_29_0_0 ; if ( ssIsMajorTimeStep ( S ) != 0 ) { rtAction
= ( int8_T ) ! ( _rtB -> B_29_5_0 > 0.0 ) ; _rtDW -> If1_ActiveSubsystem_g =
rtAction ; } else { rtAction = _rtDW -> If1_ActiveSubsystem_g ; } switch (
rtAction ) { case 0 : _rtB -> B_29_40_0 = 0.0 ; _rtB -> B_29_40_0 += _rtP ->
P_19 * _rtX -> StateSpace_CSTATE_o ; { real_T * * uBuffer = ( real_T * * ) &
_rtDW -> TransportDelay_PWORK_k . TUbufferPtrs [ 0 ] ; real_T * * tBuffer = (
real_T * * ) & _rtDW -> TransportDelay_PWORK_k . TUbufferPtrs [ 1 ] ; real_T
simTime = ssGetT ( S ) ; real_T tMinusDelay = simTime - _rtP -> P_21 ; _rtB
-> B_7_1_0 = TBCC_Dyn_acc_rt_TDelayInterpolate ( tMinusDelay , 0.0 , *
tBuffer , * uBuffer , _rtDW -> TransportDelay_IWORK_b . CircularBufSize , &
_rtDW -> TransportDelay_IWORK_b . Last , _rtDW -> TransportDelay_IWORK_b .
Tail , _rtDW -> TransportDelay_IWORK_b . Head , _rtP -> P_22 , 1 , (
boolean_T ) ( ssIsMinorTimeStep ( S ) && ( ssGetTimeOfLastOutput ( S ) ==
ssGetT ( S ) ) ) ) ; } if ( ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC (
_rtDW -> IfActionSubsystem2_SubsysRanBC ) ; } break ; case 1 :
TBCC_Dyn_IfActionSubsystem3 ( S , _rtB -> B_29_24_0 , & _rtB -> B_29_40_0 ) ;
if ( ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
IfActionSubsystem3_m . IfActionSubsystem3_SubsysRanBC ) ; } break ; } _rtB ->
B_29_41_0 = _rtB -> B_29_40_0 + _rtB -> B_29_5_0 ; i = ssIsSampleHit ( S , 1
, 0 ) ; if ( i != 0 ) { ssCallAccelRunBlock ( S , 29 , 42 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 29 , 43 ,
SS_CALL_MDL_OUTPUTS ) ; rtb_B_29_44_0 = _rtB -> B_29_27_0 ; _rtB -> B_29_47_0
= ( _rtB -> B_29_27_0 * _rtB -> B_29_3_0 + _rtB -> B_29_2_0 ) * _rtP -> P_194
; } _rtB -> B_29_49_0 = _rtB -> B_29_47_0 - _rtP -> P_195 * rtb_B_29_13_0 ; i
= ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_29_50_0 = _rtB ->
B_29_0_0_m ; if ( ssIsMajorTimeStep ( S ) != 0 ) { if ( _rtB -> B_29_50_0 >
0.0 ) { if ( ! _rtDW -> NoiseGenerator_MODE ) { if ( ssGetTaskTime ( S , 1 )
!= ssGetTStart ( S ) ) { ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; }
_rtDW -> NoiseGenerator_MODE = true ; } } else { if ( _rtDW ->
NoiseGenerator_MODE ) { ssSetBlockStateForSolverChangedAtMajorStep ( S ) ;
_rtDW -> NoiseGenerator_MODE = false ; } } } } if ( _rtDW ->
NoiseGenerator_MODE ) { i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) {
B_24_3_0_idx_0 = rtb_B_29_44_0 / _rtB -> B_29_1_0_c ; if ( B_24_3_0_idx_0 >
_rtP -> P_0 ) { B_24_3_0_idx_0 = _rtP -> P_0 ; } else { if ( B_24_3_0_idx_0 <
_rtP -> P_1 ) { B_24_3_0_idx_0 = _rtP -> P_1 ; } } _rtB -> B_0_3_0 =
B_24_3_0_idx_0 * _rtDW -> NextOutput ; } _rtB -> B_0_5_0 = ( _rtP -> P_7 *
_rtX -> noisegeneratingfilter_CSTATE + _rtP -> P_8 * _rtB -> B_0_3_0 ) * _rtP
-> P_10 ; if ( ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
NoiseGenerator_SubsysRanBC ) ; } } _rtB -> B_29_52_0 = _rtP -> P_196 *
rtb_B_29_17_0 ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { B_29_53_0 =
rtb_B_27_0_0 ; B_29_54_0 = _rtB -> B_27_5_0 [ 3 ] ; B_29_55_0 = _rtB ->
B_27_24_0 [ 0 ] ; B_29_56_0 = _rtB -> B_27_24_0 [ 1 ] ; B_29_57_0 = _rtB ->
B_27_24_0 [ 2 ] ; B_29_58_0 = _rtB -> B_27_24_0 [ 3 ] ; B_29_59_0 = _rtB ->
B_27_24_0 [ 4 ] ; B_29_60_0 = _rtB -> B_27_26_0 [ 0 ] ; B_29_61_0 = _rtB ->
B_27_26_0 [ 1 ] ; B_29_62_0 = _rtB -> B_27_26_0 [ 2 ] ; B_29_63_0 = _rtB ->
B_27_26_0 [ 3 ] ; B_29_64_0 = _rtB -> B_27_5_0 [ 0 ] ; B_29_65_0 = _rtB ->
B_27_26_0 [ 4 ] ; B_29_66_0 = _rtB -> B_27_39_0 [ 0 ] ; B_29_67_0 = _rtB ->
B_27_39_0 [ 1 ] ; B_29_68_0 = _rtB -> B_27_39_0 [ 2 ] ; B_29_69_0 = _rtB ->
B_27_39_0 [ 3 ] ; B_29_70_0 = _rtB -> B_27_39_0 [ 4 ] ; B_29_71_0 = _rtB ->
B_27_39_0 [ 0 ] ; B_29_72_0 = _rtB -> B_27_39_0 [ 1 ] ; B_29_73_0 = _rtB ->
B_27_39_0 [ 2 ] ; B_29_74_0 = rtb_B_27_40_0 ; B_29_75_0 = _rtB -> B_27_5_0 [
1 ] ; B_29_76_0 = _rtB -> B_27_39_0 [ 4 ] ; B_29_77_0 = _rtB -> B_27_5_0 [ 4
] ; B_29_78_0 = _rtB -> B_27_5_0 [ 5 ] ; B_29_79_0 = _rtB -> B_27_5_0 [ 6 ] ;
B_29_80_0 = rtb_B_27_6_0 ; B_29_81_0 = _rtB -> B_27_5_0 [ 7 ] ; B_29_82_0 =
_rtB -> B_27_24_0 [ 7 ] ; B_29_83_0 = _rtB -> B_27_24_0 [ 8 ] ; B_29_84_0 =
_rtB -> B_27_24_0 [ 9 ] ; B_29_85_0 = _rtB -> B_27_24_0 [ 10 ] ; B_29_86_0 =
_rtB -> B_27_5_0 [ 2 ] ; B_29_87_0 = _rtB -> B_27_24_0 [ 11 ] ; B_29_88_0 =
_rtB -> B_27_24_0 [ 12 ] ; B_29_89_0 = _rtB -> B_27_24_0 [ 13 ] ; B_29_90_0 =
_rtB -> B_27_24_0 [ 14 ] ; B_29_91_0 = _rtB -> B_27_24_0 [ 15 ] ; B_29_92_0 =
_rtB -> B_27_24_0 [ 16 ] ; B_29_93_0 = _rtB -> B_27_24_0 [ 17 ] ; B_29_94_0 =
_rtB -> B_27_24_0 [ 18 ] ; B_29_95_0 = _rtB -> B_27_24_0 [ 19 ] ; B_29_96_0 =
_rtB -> B_27_24_0 [ 20 ] ; B_29_97_0 = _rtB -> B_27_5_0 [ 3 ] ; B_29_98_0 =
_rtB -> B_27_24_0 [ 21 ] ; B_29_99_0 = _rtB -> B_27_24_0 [ 22 ] ; B_29_100_0
= _rtB -> B_27_24_0 [ 23 ] ; B_29_101_0 = _rtB -> B_27_24_0 [ 24 ] ;
B_29_102_0 = _rtB -> B_27_24_0 [ 25 ] ; B_29_103_0 = _rtB -> B_27_24_0 [ 26 ]
; B_29_104_0 = rtb_B_27_1_0 ; memcpy ( & B_29_105_0 [ 0 ] , & rtb_B_27_29_0 [
0 ] , 53U * sizeof ( real_T ) ) ; B_29_106_0 = B_27_13_0_idx_0 ; B_29_107_0 =
B_27_13_0_idx_1 ; B_29_108_0 = rtb_B_27_2_0 ; B_29_109_0 = B_27_13_0_idx_2 ;
B_29_110_0 = _rtB -> B_27_39_0 [ 7 ] ; B_29_111_0 = _rtB -> B_27_39_0 [ 8 ] ;
B_29_112_0 = _rtB -> B_27_39_0 [ 9 ] ; B_29_113_0 = _rtB -> B_27_39_0 [ 10 ]
; B_29_114_0 = _rtB -> B_27_39_0 [ 11 ] ; B_29_115_0 = _rtB -> B_27_39_0 [ 12
] ; B_29_116_0 = _rtB -> B_27_39_0 [ 13 ] ; B_29_117_0 = _rtB -> B_27_39_0 [
14 ] ; B_29_118_0 = _rtB -> B_27_39_0 [ 15 ] ; B_29_119_0 = _rtB -> B_27_5_0
[ 0 ] ; B_29_120_0 = _rtB -> B_27_39_0 [ 16 ] ; B_29_121_0 = _rtB ->
B_27_39_0 [ 17 ] ; B_29_122_0 = _rtB -> B_27_39_0 [ 18 ] ; B_29_123_0 = _rtB
-> B_27_39_0 [ 19 ] ; B_29_124_0 = rtb_B_27_3_0 ; memcpy ( & B_29_125_0 [ 0 ]
, & rtb_B_27_51_0 [ 0 ] , 50U * sizeof ( real_T ) ) ; B_29_126_0 =
B_27_31_0_idx_0 ; B_29_127_0 = B_27_31_0_idx_1 ; B_29_128_0 = _rtB ->
B_27_42_0 [ 1 ] ; B_29_129_0 = _rtB -> B_27_48_0 ; B_29_130_0 = _rtB ->
B_27_5_0 [ 1 ] ; B_29_131_0 = rtb_B_27_10_0 ; B_29_132_0 [ 0 ] = _rtB ->
B_27_42_0 [ 2 ] ; B_29_132_0 [ 1 ] = _rtB -> B_27_39_0 [ 6 ] ; B_29_132_0 [ 2
] = _rtB -> B_27_24_0 [ 6 ] ; B_29_133_0 = rtb_B_27_9_0 ; ssCallAccelRunBlock
( S , 29 , 134 , SS_CALL_MDL_OUTPUTS ) ; i = ssIsSpecialSampleHit ( S , 2 , 1
, 0 ) ; if ( i != 0 ) { _rtB -> B_29_135_0 = _rtDW ->
TmpRTBAtDivideInport2_Buffer0 ; } } i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i
!= 0 ) { i = ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if ( i != 0 ) { _rtB ->
B_29_137_0 = _rtDW -> TmpRTBAtProductInport2_Buffer0 ; } } rtb_B_29_138_0 =
_rtB -> B_29_0_0 / _rtB -> B_29_135_0 * _rtB -> B_29_137_0 ; i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { i = ssIsSpecialSampleHit ( S ,
2 , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_29_139_0 = _rtDW ->
TmpRTBAtSqrt2Outport1_Buffer0 ; } } i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i
!= 0 ) { i = ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if ( i != 0 ) { _rtB ->
B_29_141_0 = _rtDW -> TmpRTBAtProduct6Inport2_Buffer0 ; } } _rtB ->
B_29_143_0 = rtb_B_29_138_0 / _rtB -> B_29_139_0 * _rtB -> B_29_141_0 * ( 1.0
/ rtb_B_29_138_0 ) ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) {
ssCallAccelRunBlock ( S , 29 , 144 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 29 , 145 , SS_CALL_MDL_OUTPUTS ) ; i =
ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_29_146_0 =
_rtDW -> TmpRTBAtProduct3Inport1_Buffer0 ; } } i = ssIsSampleHit ( S , 1 , 0
) ; if ( i != 0 ) { i = ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if ( i != 0
) { _rtB -> B_29_148_0 = _rtDW -> TmpRTBAtDivide2Inport2_Buffer0 ; } }
rtb_B_29_149_0 = _rtB -> B_29_146_0 * rtb_B_29_138_0 / _rtB -> B_29_148_0 ; i
= ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { i = ssIsSpecialSampleHit ( S
, 2 , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_29_151_0 = _rtDW ->
TmpRTBAtIfActionSubsystem1Inport1_Buffer0_h ; } i = ssIsSpecialSampleHit ( S
, 2 , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_29_152_0 = _rtDW ->
TmpRTBAtIfActionSubsystem1Inport1_Buffer0_hu ; } } if ( ssIsMajorTimeStep ( S
) != 0 ) { rtAction = ( int8_T ) ! ( _rtB -> B_29_24_0 >= 1.0 ) ; _rtDW ->
If_ActiveSubsystem = rtAction ; } else { rtAction = _rtDW ->
If_ActiveSubsystem ; } switch ( rtAction ) { case 0 : { real_T * * uBuffer =
( real_T * * ) & _rtDW -> TransportDelay_PWORK_h . TUbufferPtrs [ 0 ] ;
real_T * * tBuffer = ( real_T * * ) & _rtDW -> TransportDelay_PWORK_h .
TUbufferPtrs [ 1 ] ; real_T simTime = ssGetT ( S ) ; real_T tMinusDelay =
simTime - _rtP -> P_15 ; _rtB -> B_29_156_0 =
TBCC_Dyn_acc_rt_TDelayInterpolate ( tMinusDelay , 0.0 , * tBuffer , * uBuffer
, _rtDW -> TransportDelay_IWORK_j . CircularBufSize , & _rtDW ->
TransportDelay_IWORK_j . Last , _rtDW -> TransportDelay_IWORK_j . Tail ,
_rtDW -> TransportDelay_IWORK_j . Head , _rtP -> P_16 , 1 , ( boolean_T ) (
ssIsMinorTimeStep ( S ) && ( ssGetTimeOfLastOutput ( S ) == ssGetT ( S ) ) )
) ; } if ( ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
IfActionSubsystem_SubsysRanBC ) ; } break ; case 1 :
TBCC_Dyn_IfActionSubsystem3 ( S , _rtB -> B_29_152_0 , & _rtB -> B_29_156_0 )
; if ( ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
IfActionSubsystem1_c . IfActionSubsystem3_SubsysRanBC ) ; } break ; } i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { i = ssIsSpecialSampleHit ( S ,
2 , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_29_157_0 = _rtDW ->
TmpRTBAtIfActionSubsystemInport1_Buffer0 ; } ssCallAccelRunBlock ( S , 29 ,
158 , SS_CALL_MDL_OUTPUTS ) ; } _rtB -> B_29_159_0 = muDoubleScalarMax ( _rtB
-> B_29_40_0 , _rtB -> B_29_5_0 ) ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i
!= 0 ) { ssCallAccelRunBlock ( S , 29 , 160 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 29 , 161 , SS_CALL_MDL_OUTPUTS ) ; i =
ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_29_162_0 =
_rtDW -> TmpRTBAtIfActionSubsystem2Inport1_Buffer0 ; } ssCallAccelRunBlock (
S , 29 , 163 , SS_CALL_MDL_OUTPUTS ) ; } B_29_165_0 = rt_Lookup ( _rtP ->
P_207 , 7 , ssGetT ( S ) , _rtP -> P_208 ) ; i = ssIsSampleHit ( S , 1 , 0 )
; if ( i != 0 ) { i = ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if ( i != 0 )
{ _rtB -> B_29_166_0 = _rtDW -> TmpRTBAtBiasOutport1_Buffer0 ; } } _rtB ->
B_29_167_0 = _rtB -> B_29_0_0 / _rtB -> B_29_166_0 ; i = ssIsSampleHit ( S ,
1 , 0 ) ; if ( i != 0 ) { ssCallAccelRunBlock ( S , 29 , 168 ,
SS_CALL_MDL_OUTPUTS ) ; i = ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if ( i
!= 0 ) { _rtB -> B_29_169_0 = _rtDW -> TmpRTBAtProduct1Inport2_Buffer0 ; } }
_rtB -> B_29_171_0 = _rtB -> B_29_0_0 * _rtB -> B_29_169_0 / _rtB ->
B_29_166_0 ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) {
ssCallAccelRunBlock ( S , 29 , 172 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 29 , 173 , SS_CALL_MDL_OUTPUTS ) ; i =
ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_29_174_0 =
_rtDW -> TmpRTBAtProduct5Inport2_Buffer0 ; } } _rtB -> B_29_175_0 =
rtb_B_29_138_0 * _rtB -> B_29_174_0 ; i = ssIsSampleHit ( S , 1 , 0 ) ; if (
i != 0 ) { ssCallAccelRunBlock ( S , 29 , 176 , SS_CALL_MDL_OUTPUTS ) ; i =
ssIsSpecialSampleHit ( S , 2 , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_29_177_0 =
_rtDW -> TmpRTBAtProduct6Inport2_Buffer0_l ; } } _rtB -> B_29_178_0 =
muDoubleScalarSqrt ( rtb_B_29_149_0 ) * _rtB -> B_29_177_0 ; i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { ssCallAccelRunBlock ( S , 29 ,
179 , SS_CALL_MDL_OUTPUTS ) ; } _rtB -> B_29_182_0 = muDoubleScalarPower (
_rtP -> P_213 * _rtB -> B_29_178_0 , 2.0 ) * _rtP -> P_214 ; i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { ssCallAccelRunBlock ( S , 29 ,
183 , SS_CALL_MDL_OUTPUTS ) ; } _rtB -> B_29_185_0 = _rtB -> B_29_175_0 / (
_rtP -> P_215 * _rtB -> B_29_182_0 ) ; i = ssIsSampleHit ( S , 1 , 0 ) ; if (
i != 0 ) { ssCallAccelRunBlock ( S , 29 , 186 , SS_CALL_MDL_OUTPUTS ) ; } if
( ssGetTaskTime ( S , 0 ) < _rtP -> P_216 ) { B_27_13_0_idx_0 = _rtP -> P_217
; } else { B_27_13_0_idx_0 = _rtP -> P_218 ; } _rtB -> B_29_191_0 = ( ssGetT
( S ) - _rtB -> B_29_10_0 ) * B_27_13_0_idx_0 + _rtB -> B_29_11_0 ;
ssCallAccelRunBlock ( S , 29 , 192 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 29 , 193 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 29 , 194 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 29 , 195 , SS_CALL_MDL_OUTPUTS ) ; i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { ssCallAccelRunBlock ( S , 29 ,
196 , SS_CALL_MDL_OUTPUTS ) ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 )
{ ssCallAccelRunBlock ( S , 28 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_28_1_0
[ 0 ] = _rtB -> B_28_0_0 ; _rtB -> B_28_1_0 [ 1 ] = _rtB -> B_28_1_0_b ; } }
} if ( ssIsSampleHit ( S , 2 , tid ) ) { mdlOutputsTID2 ( S , tid ) ; }
UNUSED_PARAMETER ( tid ) ; } void mdlOutputsTID2 ( SimStruct * S , int_T tid
) { real_T rtb_B_29_2_0 ; real_T rtb_B_29_6_0 ; real_T rtb_B_29_1_0 ; real_T
rtb_B_29_7_0 ; real_T rtb_B_29_10_0 ; real_T rtb_B_29_14_0 ; real_T
rtb_B_29_30_0 ; real_T rtb_B_29_27_0 ; real_T rtb_B_29_43_0 ; real_T
rtb_B_29_45_0 ; real_T rtb_B_29_36_0 ; real_T rtb_B_29_55_0 ; real_T
rtb_B_29_57_0 ; real_T rtb_B_29_20_0 ; real_T rtb_B_29_22_0 ; real_T
rtb_B_29_23_0 ; real_T rtb_B_29_24_0 ; real_T rtb_B_29_46_0 ; real_T
rtb_B_29_49_0 ; real_T rtb_B_29_50_0 ; real_T rtb_B_29_51_0 ; real_T
rtb_B_29_66_0 ; real_T rtb_B_29_68_0 ; real_T rtb_B_29_70_0 ; real_T
rtb_B_29_71_0 ; real_T rtb_B_29_74_0 ; real_T rtb_B_29_80_0 ; real_T
rtb_B_29_81_0 ; real_T rtb_B_29_75_0 ; real_T rtb_B_29_13_0 ; real_T B_29_6_0
; B_TBCC_Dyn_T * _rtB ; P_TBCC_Dyn_T * _rtP ; DW_TBCC_Dyn_T * _rtDW ; _rtDW =
( ( DW_TBCC_Dyn_T * ) ssGetRootDWork ( S ) ) ; _rtP = ( ( P_TBCC_Dyn_T * )
ssGetModelRtp ( S ) ) ; _rtB = ( ( B_TBCC_Dyn_T * ) _ssGetModelBlockIO ( S )
) ; rtb_B_29_1_0 = _rtP -> P_220 ; rtb_B_29_2_0 = _rtP -> P_220 + _rtP ->
P_221 ; _rtB -> B_29_4_0 = _rtP -> P_222 ; rtb_B_29_6_0 = _rtB -> B_29_4_0 /
_rtP -> P_223 ; rtb_B_29_7_0 = rtb_B_29_2_0 / _rtP -> P_220 ; if ( (
rtb_B_29_6_0 < 0.0 ) && ( rtb_B_29_7_0 > muDoubleScalarFloor ( rtb_B_29_7_0 )
) ) { B_29_6_0 = - muDoubleScalarPower ( - rtb_B_29_6_0 , rtb_B_29_7_0 ) ; }
else { B_29_6_0 = muDoubleScalarPower ( rtb_B_29_6_0 , rtb_B_29_7_0 ) ; }
rtb_B_29_10_0 = _rtP -> P_219 / rtb_B_29_2_0 * ( B_29_6_0 + _rtP -> P_224 ) ;
rtb_B_29_13_0 = rtb_B_29_10_0 * rtb_B_29_2_0 * _rtP -> P_225 + _rtP -> P_226
; rtb_B_29_14_0 = 1.0 / rtb_B_29_2_0 * _rtP -> P_220 ; if ( ( rtb_B_29_13_0 <
0.0 ) && ( rtb_B_29_14_0 > muDoubleScalarFloor ( rtb_B_29_14_0 ) ) ) {
B_29_6_0 = - muDoubleScalarPower ( - rtb_B_29_13_0 , rtb_B_29_14_0 ) ; } else
{ B_29_6_0 = muDoubleScalarPower ( rtb_B_29_13_0 , rtb_B_29_14_0 ) ; } _rtB
-> B_29_16_0 = 1.0 / B_29_6_0 * _rtB -> B_29_4_0 ; ssCallAccelRunBlock ( S ,
29 , 215 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 29 , 216 ,
SS_CALL_MDL_OUTPUTS ) ; rtb_B_29_20_0 = _rtP -> P_228 ; rtb_B_29_22_0 = _rtP
-> P_230 ; rtb_B_29_23_0 = _rtP -> P_231 ; rtb_B_29_24_0 = _rtP -> P_232 ;
rtb_B_29_27_0 = rtb_B_29_1_0 + _rtP -> P_235 ; rtb_B_29_30_0 = _rtB ->
B_29_16_0 / _rtB -> B_29_4_0 ; rtb_B_29_36_0 = _rtP -> P_240 ; _rtB ->
B_29_37_0 = _rtP -> P_240 + _rtP -> P_241 ; _rtB -> B_29_38_0 = _rtP -> P_239
/ _rtB -> B_29_37_0 ; rtb_B_29_43_0 = ( rtb_B_29_10_0 * rtb_B_29_2_0 + _rtP
-> P_236 ) * ( 1.0 / rtb_B_29_27_0 ) ; rtb_B_29_45_0 = rtb_B_29_27_0 / ( _rtP
-> P_242 * rtb_B_29_2_0 ) ; if ( ( rtb_B_29_43_0 < 0.0 ) && ( rtb_B_29_45_0 >
muDoubleScalarFloor ( rtb_B_29_45_0 ) ) ) { rtb_B_29_46_0 = -
muDoubleScalarPower ( - rtb_B_29_43_0 , rtb_B_29_45_0 ) ; } else {
rtb_B_29_46_0 = muDoubleScalarPower ( rtb_B_29_43_0 , rtb_B_29_45_0 ) ; }
rtb_B_29_49_0 = muDoubleScalarSqrt ( _rtP -> P_238 * _rtB -> B_29_38_0 * _rtP
-> P_227 / ( rtb_B_29_1_0 * _rtP -> P_229 ) ) ; rtb_B_29_50_0 =
muDoubleScalarSqrt ( rtb_B_29_10_0 ) ; if ( ( rtb_B_29_30_0 < 0.0 ) && (
rtb_B_29_7_0 > muDoubleScalarFloor ( rtb_B_29_7_0 ) ) ) { B_29_6_0 = -
muDoubleScalarPower ( - rtb_B_29_30_0 , rtb_B_29_7_0 ) ; } else { B_29_6_0 =
muDoubleScalarPower ( rtb_B_29_30_0 , rtb_B_29_7_0 ) ; } rtb_B_29_51_0 =
muDoubleScalarSqrt ( ( - B_29_6_0 + _rtP -> P_237 ) * ( _rtP -> P_243 *
rtb_B_29_14_0 ) * _rtP -> P_233 * _rtP -> P_234 ) ; _rtDW ->
TmpRTBAtDivide2Inport2_Buffer0 = rtb_B_29_22_0 ; rtb_B_29_55_0 =
rtb_B_29_36_0 / ( rtb_B_29_36_0 + _rtP -> P_245 ) ; if ( ( _rtB -> B_29_38_0
< 0.0 ) && ( rtb_B_29_55_0 > muDoubleScalarFloor ( rtb_B_29_55_0 ) ) ) {
B_29_6_0 = - muDoubleScalarPower ( - _rtB -> B_29_38_0 , rtb_B_29_55_0 ) ; }
else { B_29_6_0 = muDoubleScalarPower ( _rtB -> B_29_38_0 , rtb_B_29_55_0 ) ;
} rtb_B_29_57_0 = _rtP -> P_244 * B_29_6_0 ; _rtDW ->
TmpRTBAtDivideInport2_Buffer0 = rtb_B_29_57_0 ; _rtDW ->
TmpRTBAtIfActionSubsystem1Inport1_Buffer0_h = rtb_B_29_51_0 ; _rtDW ->
TmpRTBAtIfActionSubsystem3Inport1_Buffer0 = rtb_B_29_24_0 ; _rtDW ->
TmpRTBAtIfActionSubsystem4Inport1_Buffer0 = rtb_B_29_23_0 ; _rtDW ->
TmpRTBAtProduct3Inport1_Buffer0 = rtb_B_29_20_0 ; _rtDW ->
TmpRTBAtProduct6Inport2_Buffer0 = rtb_B_29_46_0 ; _rtDW ->
TmpRTBAtProductInport2_Buffer0 = rtb_B_29_49_0 ; _rtDW ->
TmpRTBAtSqrt2Outport1_Buffer0 = rtb_B_29_50_0 ; rtb_B_29_66_0 = _rtP -> P_246
; _rtDW -> TmpRTBAtIfActionSubsystem1Inport1_Buffer0_hu = rtb_B_29_66_0 ;
rtb_B_29_68_0 = _rtP -> P_247 ; _rtDW ->
TmpRTBAtIfActionSubsystemInport1_Buffer0 = rtb_B_29_68_0 ; rtb_B_29_70_0 =
_rtP -> P_248 ; rtb_B_29_71_0 = _rtP -> P_249 ; _rtDW ->
TmpRTBAtIfActionSubsystem1Inport1_Buffer0 = rtb_B_29_71_0 ; _rtDW ->
TmpRTBAtIfActionSubsystem2Inport1_Buffer0 = rtb_B_29_70_0 ; rtb_B_29_74_0 =
_rtP -> P_250 ; rtb_B_29_75_0 = rtb_B_29_74_0 + _rtP -> P_251 ; _rtDW ->
TmpRTBAtBiasOutport1_Buffer0 = rtb_B_29_75_0 ; _rtDW ->
TmpRTBAtProduct1Inport2_Buffer0 = rtb_B_29_74_0 ; ssCallAccelRunBlock ( S ,
29 , 261 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 29 , 262 ,
SS_CALL_MDL_OUTPUTS ) ; rtb_B_29_80_0 = _rtP -> P_252 ; rtb_B_29_81_0 = _rtP
-> P_253 ; _rtDW -> TmpRTBAtProduct5Inport2_Buffer0 = rtb_B_29_80_0 ; _rtDW
-> TmpRTBAtProduct6Inport2_Buffer0_l = rtb_B_29_81_0 ; UNUSED_PARAMETER ( tid
) ; } static void mdlOutputsTID3 ( SimStruct * S , int_T tid ) { int32_T
B_27_18_0 ; int32_T i ; B_TBCC_Dyn_T * _rtB ; P_TBCC_Dyn_T * _rtP ; _rtP = (
( P_TBCC_Dyn_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( ( B_TBCC_Dyn_T * )
_ssGetModelBlockIO ( S ) ) ; _rtB -> B_29_0_0_m = _rtP -> P_254 ; _rtB ->
B_29_1_0_c = _rtP -> P_255 ; _rtB -> B_29_2_0 = _rtP -> P_256 ; _rtB ->
B_29_3_0 = _rtP -> P_257 ; _rtB -> B_29_5_0_k = _rtP -> P_258 ; _rtB ->
B_29_6_0 = _rtP -> P_259 ; _rtB -> B_27_0_0 = _rtP -> P_143 ; _rtB ->
B_27_1_0 = _rtP -> P_144 ; _rtB -> B_27_2_0 = _rtP -> P_145 ; _rtB ->
B_27_3_0 = _rtP -> P_146 ; _rtB -> B_27_4_0_p = _rtP -> P_147 ; _rtB ->
B_27_5_0_c = _rtP -> P_148 ; _rtB -> B_27_6_0 = _rtP -> P_149 ; _rtB ->
B_27_7_0 = _rtP -> P_150 ; _rtB -> B_27_8_0 = _rtP -> P_151 ; _rtB ->
B_27_11_0_p = ( _rtP -> P_152 == _rtP -> P_153 ) ; _rtB -> B_27_12_0 = _rtP
-> P_154 ; _rtB -> B_27_13_0 = _rtP -> P_155 ; _rtB -> B_27_14_0 = _rtP ->
P_156 ; _rtB -> B_27_16_0 = ! _rtB -> B_27_11_0_p ; _rtB -> B_27_17_0 = _rtP
-> P_157 ; B_27_18_0 = _rtP -> P_264 ; _rtB -> B_27_19_0 = _rtP -> P_158 ;
_rtB -> B_27_22_0 = _rtP -> P_159 - _rtP -> P_160 ; _rtB -> B_27_23_0_f =
_rtP -> P_161 ; _rtB -> B_27_24_0_g = _rtP -> P_162 ; _rtB -> B_27_27_0_l = (
_rtP -> P_163 == _rtP -> P_164 ) ; _rtB -> B_27_28_0 = _rtP -> P_165 ; _rtB
-> B_27_29_0 = _rtP -> P_166 ; _rtB -> B_27_30_0 = _rtP -> P_167 ; _rtB ->
B_27_31_0 = _rtP -> P_168 ; _rtB -> B_27_32_0 = _rtP -> P_169 ; _rtB ->
B_27_35_0 = ( _rtP -> P_170 == _rtP -> P_171 ) ; _rtB -> B_27_36_0 = _rtP ->
P_172 ; _rtB -> B_27_37_0 = _rtP -> P_173 ; _rtB -> B_27_39_0_g = ! _rtB ->
B_27_35_0 ; _rtB -> B_21_0_0 [ 0 ] = _rtP -> P_48 [ 0 ] ; _rtB -> B_21_0_0 [
1 ] = _rtP -> P_48 [ 1 ] ; _rtB -> B_21_0_0 [ 2 ] = _rtP -> P_48 [ 2 ] ; _rtB
-> B_21_1_0_n = _rtP -> P_265 ; for ( i = 0 ; i < 6 ; i ++ ) { _rtB ->
B_20_0_0 [ i ] = _rtP -> P_43 [ i ] ; } _rtB -> B_20_1_0 = _rtP -> P_44 ;
_rtB -> B_20_4_0_m = _rtP -> P_45 + _rtP -> P_46 ; _rtB -> B_26_0_0 = _rtP ->
P_56 ; _rtB -> B_26_1_0 = _rtP -> P_57 ; _rtB -> B_24_0_0 [ 0 ] = _rtP ->
P_50 [ 0 ] ; _rtB -> B_24_1_0 [ 0 ] = _rtP -> P_51 [ 0 ] ; _rtB -> B_24_0_0 [
1 ] = _rtP -> P_50 [ 1 ] ; _rtB -> B_24_1_0 [ 1 ] = _rtP -> P_51 [ 1 ] ; _rtB
-> B_24_0_0 [ 2 ] = _rtP -> P_50 [ 2 ] ; _rtB -> B_24_1_0 [ 2 ] = _rtP ->
P_51 [ 2 ] ; _rtB -> B_24_2_0 = _rtP -> P_52 ; _rtB -> B_24_3_0 = _rtP ->
P_53 ; _rtB -> B_24_4_0 = _rtP -> P_54 ; _rtB -> B_29_8_0_c = _rtP -> P_260 ;
_rtB -> B_29_9_0 = _rtP -> P_261 ; _rtB -> B_29_10_0 = _rtP -> P_262 ; _rtB
-> B_29_11_0 = _rtP -> P_263 ; _rtB -> B_28_0_0 = 0.0 ; _rtB -> B_28_1_0_b =
0.0 ; UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { int32_T isHit ;
B_TBCC_Dyn_T * _rtB ; P_TBCC_Dyn_T * _rtP ; DW_TBCC_Dyn_T * _rtDW ; _rtDW = (
( DW_TBCC_Dyn_T * ) ssGetRootDWork ( S ) ) ; _rtP = ( ( P_TBCC_Dyn_T * )
ssGetModelRtp ( S ) ) ; _rtB = ( ( B_TBCC_Dyn_T * ) _ssGetModelBlockIO ( S )
) ; if ( ssIsContinuousTask ( S , 0 ) != 0 ) { if ( _rtDW ->
If2_ActiveSubsystem == 0 ) { { real_T * * uBuffer = ( real_T * * ) & _rtDW ->
TransportDelay_PWORK . TUbufferPtrs [ 0 ] ; real_T * * tBuffer = ( real_T * *
) & _rtDW -> TransportDelay_PWORK . TUbufferPtrs [ 1 ] ; real_T simTime =
ssGetT ( S ) ; _rtDW -> TransportDelay_IWORK . Head = ( ( _rtDW ->
TransportDelay_IWORK . Head < ( _rtDW -> TransportDelay_IWORK .
CircularBufSize - 1 ) ) ? ( _rtDW -> TransportDelay_IWORK . Head + 1 ) : 0 )
; if ( _rtDW -> TransportDelay_IWORK . Head == _rtDW -> TransportDelay_IWORK
. Tail ) { if ( ! TBCC_Dyn_acc_rt_TDelayUpdateTailOrGrowBuf ( & _rtDW ->
TransportDelay_IWORK . CircularBufSize , & _rtDW -> TransportDelay_IWORK .
Tail , & _rtDW -> TransportDelay_IWORK . Head , & _rtDW ->
TransportDelay_IWORK . Last , simTime - _rtP -> P_36 , tBuffer , uBuffer , (
NULL ) , ( boolean_T ) 0 , false , & _rtDW -> TransportDelay_IWORK .
MaxNewBufSize ) ) { ssSetErrorStatus ( S , "tdelay memory allocation error" )
; return ; } } ( * tBuffer ) [ _rtDW -> TransportDelay_IWORK . Head ] =
simTime ; ( * uBuffer ) [ _rtDW -> TransportDelay_IWORK . Head ] = _rtB ->
B_29_8_0 ; } } isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) {
_rtDW -> UnitDelay_DSTATE = _rtB -> B_0_5_0 ; } _rtDW -> Integrator_IWORK = 0
; _rtDW -> Integrator_IWORK_k = 0 ; if ( _rtDW -> If1_ActiveSubsystem_g == 0
) { { real_T * * uBuffer = ( real_T * * ) & _rtDW -> TransportDelay_PWORK_k .
TUbufferPtrs [ 0 ] ; real_T * * tBuffer = ( real_T * * ) & _rtDW ->
TransportDelay_PWORK_k . TUbufferPtrs [ 1 ] ; real_T simTime = ssGetT ( S ) ;
_rtDW -> TransportDelay_IWORK_b . Head = ( ( _rtDW -> TransportDelay_IWORK_b
. Head < ( _rtDW -> TransportDelay_IWORK_b . CircularBufSize - 1 ) ) ? (
_rtDW -> TransportDelay_IWORK_b . Head + 1 ) : 0 ) ; if ( _rtDW ->
TransportDelay_IWORK_b . Head == _rtDW -> TransportDelay_IWORK_b . Tail ) {
if ( ! TBCC_Dyn_acc_rt_TDelayUpdateTailOrGrowBuf ( & _rtDW ->
TransportDelay_IWORK_b . CircularBufSize , & _rtDW -> TransportDelay_IWORK_b
. Tail , & _rtDW -> TransportDelay_IWORK_b . Head , & _rtDW ->
TransportDelay_IWORK_b . Last , simTime - _rtP -> P_21 , tBuffer , uBuffer ,
( NULL ) , ( boolean_T ) 0 , false , & _rtDW -> TransportDelay_IWORK_b .
MaxNewBufSize ) ) { ssSetErrorStatus ( S , "tdelay memory allocation error" )
; return ; } } ( * tBuffer ) [ _rtDW -> TransportDelay_IWORK_b . Head ] =
simTime ; ( * uBuffer ) [ _rtDW -> TransportDelay_IWORK_b . Head ] = _rtB ->
B_29_162_0 ; } } if ( _rtDW -> NoiseGenerator_MODE ) { isHit = ssIsSampleHit
( S , 1 , 0 ) ; if ( isHit != 0 ) { _rtDW -> NextOutput =
rt_nrand_Upu32_Yd_f_pw_snf ( & _rtDW -> RandSeed ) * _rtP -> P_3 + _rtP ->
P_2 ; } } if ( _rtDW -> If_ActiveSubsystem == 0 ) { { real_T * * uBuffer = (
real_T * * ) & _rtDW -> TransportDelay_PWORK_h . TUbufferPtrs [ 0 ] ; real_T
* * tBuffer = ( real_T * * ) & _rtDW -> TransportDelay_PWORK_h . TUbufferPtrs
[ 1 ] ; real_T simTime = ssGetT ( S ) ; _rtDW -> TransportDelay_IWORK_j .
Head = ( ( _rtDW -> TransportDelay_IWORK_j . Head < ( _rtDW ->
TransportDelay_IWORK_j . CircularBufSize - 1 ) ) ? ( _rtDW ->
TransportDelay_IWORK_j . Head + 1 ) : 0 ) ; if ( _rtDW ->
TransportDelay_IWORK_j . Head == _rtDW -> TransportDelay_IWORK_j . Tail ) {
if ( ! TBCC_Dyn_acc_rt_TDelayUpdateTailOrGrowBuf ( & _rtDW ->
TransportDelay_IWORK_j . CircularBufSize , & _rtDW -> TransportDelay_IWORK_j
. Tail , & _rtDW -> TransportDelay_IWORK_j . Head , & _rtDW ->
TransportDelay_IWORK_j . Last , simTime - _rtP -> P_15 , tBuffer , uBuffer ,
( NULL ) , ( boolean_T ) 0 , false , & _rtDW -> TransportDelay_IWORK_j .
MaxNewBufSize ) ) { ssSetErrorStatus ( S , "tdelay memory allocation error" )
; return ; } } ( * tBuffer ) [ _rtDW -> TransportDelay_IWORK_j . Head ] =
simTime ; ( * uBuffer ) [ _rtDW -> TransportDelay_IWORK_j . Head ] = _rtB ->
B_29_157_0 ; } } isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) {
isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { ssCallAccelRunBlock
( S , 28 , 0 , SS_CALL_MDL_UPDATE ) ; } } } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
void mdlUpdateTID2 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER ( tid ) ;
}
#define MDL_UPDATE
static void mdlUpdateTID3 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { B_TBCC_Dyn_T * _rtB ;
P_TBCC_Dyn_T * _rtP ; X_TBCC_Dyn_T * _rtX ; XDot_TBCC_Dyn_T * _rtXdot ;
DW_TBCC_Dyn_T * _rtDW ; _rtDW = ( ( DW_TBCC_Dyn_T * ) ssGetRootDWork ( S ) )
; _rtXdot = ( ( XDot_TBCC_Dyn_T * ) ssGetdX ( S ) ) ; _rtX = ( ( X_TBCC_Dyn_T
* ) ssGetContStates ( S ) ) ; _rtP = ( ( P_TBCC_Dyn_T * ) ssGetModelRtp ( S )
) ; _rtB = ( ( B_TBCC_Dyn_T * ) _ssGetModelBlockIO ( S ) ) ; _rtXdot ->
TransferFcn_CSTATE = 0.0 ; _rtXdot -> TransferFcn_CSTATE += _rtP -> P_174 *
_rtX -> TransferFcn_CSTATE ; _rtXdot -> TransferFcn_CSTATE += _rtB ->
B_29_156_0 ; ( ( XDot_TBCC_Dyn_T * ) ssGetdX ( S ) ) -> TransferFcn2_CSTATE =
0.0 ; if ( _rtDW -> If1_ActiveSubsystem == 0 ) { _rtXdot ->
TransferFcn2_CSTATE = 0.0 ; _rtXdot -> TransferFcn2_CSTATE += _rtP -> P_11 *
_rtX -> TransferFcn2_CSTATE ; _rtXdot -> TransferFcn2_CSTATE += _rtB ->
B_29_139_0 ; } { real_T * dx ; int_T i ; dx = & ( ( ( XDot_TBCC_Dyn_T * )
ssGetdX ( S ) ) -> StateSpace_CSTATE ) ; for ( i = 0 ; i < 5 ; i ++ ) { dx [
i ] = 0.0 ; } } if ( _rtDW -> If2_ActiveSubsystem == 0 ) { _rtXdot ->
StateSpace_CSTATE = 0.0 ; _rtXdot -> StateSpace_CSTATE += _rtP -> P_29 * _rtX
-> StateSpace_CSTATE ; _rtXdot -> StateSpace_CSTATE += _rtP -> P_30 * _rtB ->
B_13_9_0 ; { real_T * dx ; int_T i ; dx = & ( ( ( XDot_TBCC_Dyn_T * ) ssGetdX
( S ) ) -> StateSpace_CSTATE_m ) ; for ( i = 0 ; i < 3 ; i ++ ) { dx [ i ] =
0.0 ; } } ( ( XDot_TBCC_Dyn_T * ) ssGetdX ( S ) ) -> IfActionSubsystem2_o .
StateSpace_CSTATE_k = 0.0 ; switch ( _rtDW -> If3_ActiveSubsystem ) { case 0
: _rtXdot -> StateSpace_CSTATE_m = 0.0 ; _rtXdot -> StateSpace_CSTATE_m +=
_rtP -> P_23 * _rtX -> StateSpace_CSTATE_m ; _rtXdot -> StateSpace_CSTATE_m
+= _rtP -> P_24 * _rtB -> B_13_8_0 ; ( ( XDot_TBCC_Dyn_T * ) ssGetdX ( S ) )
-> IfActionSubsystem1_l . StateSpace_CSTATE_k = 0.0 ; ( ( XDot_TBCC_Dyn_T * )
ssGetdX ( S ) ) -> IfActionSubsystem2_or . StateSpace_CSTATE_k = 0.0 ; switch
( _rtDW -> If3_ActiveSubsystem_l ) { case 0 :
TBCC_Dyn_IfActionSubsystem1_Deriv ( S , _rtB -> B_11_6_0 , & _rtP ->
IfActionSubsystem1_l , & _rtX -> IfActionSubsystem1_l , & _rtXdot ->
IfActionSubsystem1_l ) ; break ; case 1 : TBCC_Dyn_IfActionSubsystem1_Deriv (
S , _rtB -> B_13_8_0 , & _rtP -> IfActionSubsystem2_or , & _rtX ->
IfActionSubsystem2_or , & _rtXdot -> IfActionSubsystem2_or ) ; break ; }
break ; case 1 : TBCC_Dyn_IfActionSubsystem1_Deriv ( S , _rtB -> B_13_9_0 , &
_rtP -> IfActionSubsystem2_o , & _rtX -> IfActionSubsystem2_o , & _rtXdot ->
IfActionSubsystem2_o ) ; break ; } } _rtXdot -> Integrator_CSTATE = _rtB ->
B_29_49_0 ; _rtXdot -> Integrator_CSTATE_f = _rtB -> B_29_52_0 ; _rtXdot ->
Integrator_CSTATE_i = _rtB -> B_27_48_0 ; ( ( XDot_TBCC_Dyn_T * ) ssGetdX ( S
) ) -> TransferFcn1_CSTATE = 0.0 ; if ( _rtDW -> If2_ActiveSubsystem_i == 0 )
{ _rtXdot -> TransferFcn1_CSTATE = 0.0 ; _rtXdot -> TransferFcn1_CSTATE +=
_rtP -> P_13 * _rtX -> TransferFcn1_CSTATE ; _rtXdot -> TransferFcn1_CSTATE
+= _rtB -> B_29_151_0 ; } ( ( XDot_TBCC_Dyn_T * ) ssGetdX ( S ) ) ->
StateSpace_CSTATE_o = 0.0 ; if ( _rtDW -> If1_ActiveSubsystem_g == 0 ) {
_rtXdot -> StateSpace_CSTATE_o = 0.0 ; _rtXdot -> StateSpace_CSTATE_o += _rtP
-> P_17 * _rtX -> StateSpace_CSTATE_o ; _rtXdot -> StateSpace_CSTATE_o +=
_rtP -> P_18 * _rtB -> B_7_1_0 ; } if ( _rtDW -> NoiseGenerator_MODE ) {
_rtXdot -> noisegeneratingfilter_CSTATE = 0.0 ; _rtXdot ->
noisegeneratingfilter_CSTATE += _rtP -> P_5 * _rtX ->
noisegeneratingfilter_CSTATE ; _rtXdot -> noisegeneratingfilter_CSTATE +=
_rtP -> P_6 * _rtB -> B_0_3_0 ; } else { ( ( XDot_TBCC_Dyn_T * ) ssGetdX ( S
) ) -> noisegeneratingfilter_CSTATE = 0.0 ; } } static void
mdlInitializeSizes ( SimStruct * S ) { ssSetChecksumVal ( S , 0 , 1707049290U
) ; ssSetChecksumVal ( S , 1 , 271189392U ) ; ssSetChecksumVal ( S , 2 ,
816300784U ) ; ssSetChecksumVal ( S , 3 , 925401144U ) ; { mxArray *
slVerStructMat = NULL ; mxArray * slStrMat = mxCreateString ( "simulink" ) ;
char slVerChar [ 10 ] ; int status = mexCallMATLAB ( 1 , & slVerStructMat , 1
, & slStrMat , "ver" ) ; if ( status == 0 ) { mxArray * slVerMat = mxGetField
( slVerStructMat , 0 , "Version" ) ; if ( slVerMat == NULL ) { status = 1 ; }
else { status = mxGetString ( slVerMat , slVerChar , 10 ) ; } }
mxDestroyArray ( slStrMat ) ; mxDestroyArray ( slVerStructMat ) ; if ( (
status == 1 ) || ( strcmp ( slVerChar , "10.0" ) != 0 ) ) { return ; } }
ssSetOptions ( S , SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork (
S ) != sizeof ( DW_TBCC_Dyn_T ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( B_TBCC_Dyn_T ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
P_TBCC_Dyn_T ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & TBCC_Dyn_rtDefaultP ) ; _ssSetConstBlockIO ( S , & TBCC_Dyn_rtInvariant )
; rt_InitInfAndNaN ( sizeof ( real_T ) ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { { SimStruct * childS ;
SysOutputFcn * callSysFcns ; childS = ssGetSFunction ( S , 0 ) ; callSysFcns
= ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; childS = ssGetSFunction ( S , 1 ) ; callSysFcns =
ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; } slAccRegPrmChangeFcn ( S , mdlOutputsTID3 ) ; }
static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
